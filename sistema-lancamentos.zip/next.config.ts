import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Permite rodar build/preview em paralelo ao "npm run dev" sem compartilhar a pasta .next
  // (dois processos escrevendo no mesmo .next corrompem o cache: "__webpack_modules__[moduleId] is not a function")
  distDir: process.env.NEXT_DIST_DIR || ".next",
  // mssql/tedious e undici devem rodar apenas no servidor Node.js, sem bundling
  serverExternalPackages: ["mssql", "tedious", "undici"],
  experimental: {
    serverActions: {
      // Limite para upload da imagem do comprovante (o app valida 5 MB por arquivo)
      bodySizeLimit: "8mb",
    },
  },
  eslint: { ignoreDuringBuilds: true },
};

export default nextConfig;
