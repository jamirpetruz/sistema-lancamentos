# Sistema de Lançamentos Financeiros — SAP Business One

Sistema em **Next.js 15 (App Router)** para recebimento de comprovantes de pagamento e baixa das
contas a receber no **SAP Business One via Service Layer**. Persistência em **SQL Server sem ORM**
(driver `mssql`, consultas parametrizadas).

## Fluxo

1. **user** envia o comprovante (Nº Pedido Externo, CNPJ, valor, observação e imagem/PDF) → status `PENDENTE`.
2. **admin** abre o comprovante. O sistema consulta o SAP pelo UDF do Pedido Externo e mostra:
   - Pedidos de Venda (`Orders`) e Notas Fiscais de Saída (`Invoices`) vinculados (pode haver vários de cada);
   - conferência do CNPJ com o cliente (`BusinessPartners` → `BPFiscalTaxIDCollection.TaxId0` / `FederalTaxID`);
   - parcelas em aberto, com sugestão de rateio por ordem de vencimento (editável).
3. Ao aprovar, é criado o **Contas a Receber** (`IncomingPayments`) com transferência bancária,
   aplicando o valor nas notas/parcelas — **baixa total ou parcial**. A soma aplicada deve ser igual ao valor do comprovante.
   - Um pagamento por cliente + filial (`BPLID`), já que o SAP exige isso.
   - Se um dos pagamentos falhar, os já criados nesse processamento são cancelados (`/Cancel`).
   - Antes de lançar, verifica se já existe pagamento não cancelado para o comprovante
     (marcador `SLC#<id>|` no início de *Observações*), evitando baixa em duplicidade em reprocessamentos.
4. Status: `PENDENTE` → `PROCESSANDO` → `APROVADO` | `ERRO` (pode reprocessar) | `REJEITADO` (com motivo).
   Todo evento fica no histórico do comprovante.

## Perfis

| Role  | Pode |
|-------|------|
| user  | Enviar comprovantes e ver a lista/detalhe **dos próprios** comprovantes |
| admin | Tudo do user + ver todos, aprovar (baixa no SAP), rejeitar e gerenciar usuários |

## Configuração

```powershell
Copy-Item .env.example .env.local
```

Preencha `.env.local` (banco, `AUTH_SECRET`, Service Layer, nome do UDF e conta contábil de transferência).
Para gerar o `AUTH_SECRET`:

```powershell
node -e "console.log(require('crypto').randomBytes(48).toString('base64'))"
```

Crie o banco/tabelas e o primeiro administrador:

```powershell
npm run db:init
```

```powershell
npm run db:create-admin -- "Administrador" admin@empresa.com.br "SenhaForte123"
```

Rodar:

```powershell
npm run dev
```

Produção: `npm run build` e `npm start` (sirva atrás de HTTPS e defina `AUTH_COOKIE_SECURE=true`).

> O script `sql/schema.sql` também pode ser executado diretamente pelo DBA (SSMS / sqlcmd).
> O SQL Server precisa aceitar conexões TCP com autenticação SQL (o driver `mssql` não usa autenticação integrada do Windows).

## Pontos para validar no ambiente SAP

- **`SAP_UDF_PEDIDO_EXTERNO`**: nome do campo com o prefixo `U_` (ex.: `U_PedidoExterno`), presente em OINV e ORDR.
- **`SAP_CONTA_TRANSFERENCIA`**: conta contábil (código `AcctCode`) usada na transferência do Contas a Receber.
- **Parcelas**: o Service Layer não expõe o valor pago por parcela; o sistema distribui o `PaidToDate`
  da nota entre as parcelas em ordem (mesmo critério do SAP ao baixar). Notas de parcela única não são afetadas.
- **Moeda**: considera notas em moeda local (BRL).
- **CNPJ**: com `SAP_VALIDAR_CNPJ=true`, a aprovação é bloqueada se o CNPJ não for o do cliente das notas.
- O usuário do Service Layer precisa de permissão para ler Notas/Pedidos/PNs e criar/cancelar Contas a Receber.

## Estrutura

```
sql/schema.sql                         Tabelas (Usuarios, Comprovantes, ComprovanteAnexos, ComprovanteLancamentos, ComprovanteHistorico)
scripts/db-init.mjs                    Cria o banco e aplica o schema
scripts/create-admin.mjs               Cria/redefine um admin
src/middleware.ts                      Proteção de rotas (JWT em cookie httpOnly)
src/lib/db.ts                          Pool de conexões SQL Server (mssql)
src/lib/repos/*                        Acesso a dados com SQL puro e parâmetros tipados
src/lib/auth/*                         Sessão (jose) + revalidação do usuário no banco a cada requisição
src/lib/sap/service-layer.ts           Cliente do Service Layer (login, sessão reaproveitada, paginação, erros)
src/lib/sap/recebimentos.ts            Consulta pedido externo, rateio de parcelas e lançamento do Contas a Receber
src/app/(app)/comprovantes/*           Lista, envio e detalhe/aprovação
src/app/(app)/usuarios/*               Cadastro de usuários (admin)
src/app/api/comprovantes/[id]/anexo    Download autenticado do anexo
```
