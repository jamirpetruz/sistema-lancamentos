"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { logoutAction } from "@/app/login/actions";
import type { Role } from "@/lib/types";
import {
  IconComprovantes,
  IconEnviar,
  IconFechar,
  IconLogo,
  IconMenu,
  IconSair,
  IconUsuarios,
} from "./icons";

interface ItemMenu {
  href: string;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  badge?: number;
  adminOnly?: boolean;
}

export function Sidebar({
  usuario,
  pendentes,
}: {
  usuario: { nome: string; email: string; role: Role };
  /** Comprovantes aguardando ação do admin (pendentes + erro) */
  pendentes: number;
}) {
  const pathname = usePathname();
  const [aberto, setAberto] = useState(false);

  const itens: ItemMenu[] = [
    { href: "/comprovantes", label: "Comprovantes", icon: IconComprovantes, badge: pendentes },
    { href: "/comprovantes/novo", label: "Enviar comprovante", icon: IconEnviar },
    { href: "/usuarios", label: "Usuários", icon: IconUsuarios, adminOnly: true },
  ].filter((i) => !i.adminOnly || usuario.role === "admin");

  // Item ativo = o de prefixo mais longo que casa com a rota atual
  const ativo = itens
    .filter((i) => pathname === i.href || pathname.startsWith(`${i.href}/`))
    .sort((a, b) => b.href.length - a.href.length)[0]?.href;

  // Fecha o menu mobile ao navegar
  useEffect(() => setAberto(false), [pathname]);

  // Esc fecha; trava o scroll da página com o menu aberto
  useEffect(() => {
    if (!aberto) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setAberto(false);
    document.addEventListener("keydown", onKey);
    const overflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = overflow;
    };
  }, [aberto]);

  const iniciais = usuario.nome
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((p) => p[0]!.toUpperCase())
    .join("");

  return (
    <>
      {/* Barra superior — apenas mobile/tablet */}
      <header className="sticky top-0 z-30 flex h-14 items-center gap-3 border-b border-slate-200 bg-white/90 px-4 backdrop-blur lg:hidden">
        <button
          type="button"
          onClick={() => setAberto(true)}
          className="-ml-2 rounded-lg p-2 text-slate-600 hover:bg-slate-100"
          aria-label="Abrir menu"
          aria-expanded={aberto}
          aria-controls="sidebar"
        >
          <IconMenu />
        </button>
        <Link href="/comprovantes" className="flex items-center gap-2 font-semibold text-slate-900">
          <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-brand-600 text-white">
            <IconLogo className="h-4 w-4" />
          </span>
          Lançamentos
        </Link>
        {usuario.role === "admin" && pendentes > 0 && (
          <Link
            href="/comprovantes?status=PENDENTE"
            className="ml-auto rounded-full bg-amber-100 px-2.5 py-0.5 text-xs font-semibold text-amber-800"
          >
            {pendentes} pendente{pendentes > 1 ? "s" : ""}
          </Link>
        )}
      </header>

      {/* Fundo escuro do menu mobile */}
      <div
        onClick={() => setAberto(false)}
        aria-hidden
        className={`fixed inset-0 z-40 bg-slate-900/50 transition-opacity duration-300 lg:hidden ${
          aberto ? "opacity-100" : "pointer-events-none opacity-0"
        }`}
      />

      {/* Sidebar: fixa no desktop, gaveta deslizante no mobile */}
      <aside
        id="sidebar"
        aria-label="Menu principal"
        className={`fixed inset-y-0 left-0 z-50 flex w-72 flex-col bg-slate-900 text-slate-300 transition-[transform,visibility] duration-300 ease-out lg:visible lg:w-64 lg:translate-x-0 ${
          aberto ? "visible translate-x-0 shadow-2xl" : "invisible -translate-x-full"
        }`}
      >
        <div className="flex h-16 shrink-0 items-center gap-3 px-5">
          <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-brand-600 text-white">
            <IconLogo />
          </span>
          <div className="min-w-0 leading-tight">
            <p className="truncate text-sm font-semibold text-white">Lançamentos</p>
            <p className="truncate text-xs text-slate-400">Financeiros · SAP B1</p>
          </div>
          <button
            type="button"
            onClick={() => setAberto(false)}
            className="ml-auto rounded-lg p-1.5 text-slate-400 hover:bg-slate-800 hover:text-white lg:hidden"
            aria-label="Fechar menu"
          >
            <IconFechar className="h-5 w-5" />
          </button>
        </div>

        <nav className="flex-1 overflow-y-auto px-3 py-4">
          <p className="px-3 pb-2 text-[11px] font-semibold uppercase tracking-wider text-slate-500">Menu</p>
          <ul className="space-y-1">
            {itens.map((item) => {
              const isAtivo = item.href === ativo;
              const Icon = item.icon;
              return (
                <li key={item.href}>
                  <Link
                    href={item.href}
                    aria-current={isAtivo ? "page" : undefined}
                    className={`group flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition ${
                      isAtivo ? "bg-brand-600 text-white shadow-sm" : "hover:bg-slate-800 hover:text-white"
                    }`}
                  >
                    <Icon className={`h-5 w-5 shrink-0 ${isAtivo ? "text-white" : "text-slate-400 group-hover:text-white"}`} />
                    <span className="flex-1 truncate">{item.label}</span>
                    {usuario.role === "admin" && !!item.badge && item.badge > 0 && (
                      <span
                        className={`rounded-full px-2 py-0.5 text-xs font-semibold ${
                          isAtivo ? "bg-white/20 text-white" : "bg-amber-400/15 text-amber-300"
                        }`}
                        title="Aguardando aprovação"
                      >
                        {item.badge}
                      </span>
                    )}
                  </Link>
                </li>
              );
            })}
          </ul>
        </nav>

        <div className="shrink-0 border-t border-slate-800 p-3">
          <div className="flex items-center gap-3 rounded-lg px-2 py-2">
            <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-slate-700 text-sm font-semibold text-white">
              {iniciais || "?"}
            </span>
            <div className="min-w-0 flex-1 leading-tight">
              <p className="truncate text-sm font-medium text-white">{usuario.nome}</p>
              <p className="truncate text-xs text-slate-400">{usuario.email}</p>
            </div>
            <span
              className={`rounded px-1.5 py-0.5 text-[10px] font-semibold uppercase ${
                usuario.role === "admin" ? "bg-brand-600/30 text-brand-100" : "bg-slate-700 text-slate-300"
              }`}
            >
              {usuario.role}
            </span>
          </div>
          <form action={logoutAction}>
            <button
              type="submit"
              className="mt-1 flex w-full cursor-pointer items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium text-slate-400 transition hover:bg-slate-800 hover:text-white"
            >
              <IconSair />
              Sair
            </button>
          </form>
        </div>
      </aside>
    </>
  );
}
