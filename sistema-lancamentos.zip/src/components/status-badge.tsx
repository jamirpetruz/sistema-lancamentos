import { STATUS_LABEL, type StatusComprovante } from "@/lib/types";

const CORES: Record<StatusComprovante, string> = {
  PENDENTE: "bg-amber-50 text-amber-700 ring-amber-200",
  PROCESSANDO: "bg-sky-50 text-sky-700 ring-sky-200",
  APROVADO: "bg-emerald-50 text-emerald-700 ring-emerald-200",
  REJEITADO: "bg-slate-100 text-slate-600 ring-slate-200",
  ERRO: "bg-red-50 text-red-700 ring-red-200",
};

export function StatusBadge({ status }: { status: StatusComprovante }) {
  return (
    <span className={`inline-flex rounded-full px-2.5 py-0.5 text-xs font-medium ring-1 ring-inset ${CORES[status]}`}>
      {STATUS_LABEL[status]}
    </span>
  );
}
