import { NextResponse, type NextRequest } from "next/server";
import { SESSION_COOKIE, verificarSessao } from "./lib/auth/session";

// Primeira barreira: exige sessão válida e role admin nas rotas de administração.
// As páginas e actions revalidam o usuário no banco (ver lib/auth).
export async function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;
  const sessao = await verificarSessao(req.cookies.get(SESSION_COOKIE)?.value);

  if (pathname === "/login") {
    if (sessao) return NextResponse.redirect(new URL("/comprovantes", req.url));
    return NextResponse.next();
  }

  if (!sessao) {
    if (pathname.startsWith("/api/")) {
      return NextResponse.json({ erro: "Não autenticado" }, { status: 401 });
    }
    const url = new URL("/login", req.url);
    const res = NextResponse.redirect(url);
    res.cookies.delete(SESSION_COOKIE);
    return res;
  }

  if (pathname.startsWith("/usuarios") && sessao.role !== "admin") {
    return NextResponse.redirect(new URL("/comprovantes", req.url));
  }

  return NextResponse.next();
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico).*)"],
};
