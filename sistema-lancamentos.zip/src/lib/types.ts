export type Role = "admin" | "user";

export type StatusComprovante = "PENDENTE" | "PROCESSANDO" | "APROVADO" | "REJEITADO" | "ERRO";

export const STATUS_LABEL: Record<StatusComprovante, string> = {
  PENDENTE: "Pendente",
  PROCESSANDO: "Processando",
  APROVADO: "Aprovado",
  REJEITADO: "Rejeitado",
  ERRO: "Erro no SAP",
};

export interface Usuario {
  Id: number;
  Nome: string;
  Email: string;
  Role: Role;
  Ativo: boolean;
  CriadoEm: Date;
}

export interface Comprovante {
  Id: number;
  NumeroPedidoExterno: string;
  Cnpj: string;
  ValorComprovante: number;
  Status: StatusComprovante;
  DataEnvio: Date;
  Observacao: string | null;
  UsuarioEnvioId: number;
  UsuarioEnvioNome: string;
  AprovadorId: number | null;
  AprovadorNome: string | null;
  DataDecisao: Date | null;
  MotivoRejeicao: string | null;
  UltimoErroSap: string | null;
  AnexoNome: string | null;
  AnexoMime: string | null;
}

export interface HistoricoItem {
  Id: number;
  Acao: string;
  Detalhe: string | null;
  CriadoEm: Date;
  UsuarioNome: string | null;
}

export interface LancamentoSap {
  Id: number;
  PagamentoDocEntry: number;
  PagamentoDocNum: number | null;
  CardCode: string;
  NotaDocEntry: number;
  NotaDocNum: number | null;
  Parcela: number;
  ValorAplicado: number;
  CriadoEm: Date;
}
