import "server-only";
import { db, sql } from "../db";
import type { Role, Usuario } from "../types";

const COLUNAS = "Id, Nome, Email, Role, Ativo, CriadoEm";

export async function listarUsuarios(): Promise<Usuario[]> {
  const r = await (await db()).query<Usuario>(`SELECT ${COLUNAS} FROM dbo.Usuarios ORDER BY Nome`);
  return r.recordset;
}

export async function obterUsuario(id: number): Promise<Usuario | null> {
  const r = await (await db())
    .input("id", sql.Int, id)
    .query<Usuario>(`SELECT ${COLUNAS} FROM dbo.Usuarios WHERE Id = @id`);
  return r.recordset[0] ?? null;
}

export async function obterUsuarioParaLogin(
  email: string,
): Promise<(Usuario & { SenhaHash: string }) | null> {
  const r = await (await db())
    .input("email", sql.NVarChar(255), email.trim().toLowerCase())
    .query<Usuario & { SenhaHash: string }>(
      `SELECT ${COLUNAS}, SenhaHash FROM dbo.Usuarios WHERE Email = @email`,
    );
  return r.recordset[0] ?? null;
}

export async function emailEmUso(email: string, ignorarId?: number): Promise<boolean> {
  const r = await (await db())
    .input("email", sql.NVarChar(255), email.trim().toLowerCase())
    .input("id", sql.Int, ignorarId ?? 0)
    .query(`SELECT 1 AS x FROM dbo.Usuarios WHERE Email = @email AND Id <> @id`);
  return r.recordset.length > 0;
}

export async function criarUsuario(dados: {
  nome: string;
  email: string;
  senhaHash: string;
  role: Role;
  ativo: boolean;
}): Promise<number> {
  const r = await (await db())
    .input("nome", sql.NVarChar(150), dados.nome)
    .input("email", sql.NVarChar(255), dados.email.trim().toLowerCase())
    .input("hash", sql.NVarChar(100), dados.senhaHash)
    .input("role", sql.VarChar(10), dados.role)
    .input("ativo", sql.Bit, dados.ativo)
    .query<{ Id: number }>(`
      INSERT INTO dbo.Usuarios (Nome, Email, SenhaHash, Role, Ativo)
      OUTPUT inserted.Id
      VALUES (@nome, @email, @hash, @role, @ativo)
    `);
  return r.recordset[0].Id;
}

export async function atualizarUsuario(
  id: number,
  dados: { nome: string; email: string; role: Role; ativo: boolean; senhaHash?: string },
): Promise<void> {
  const req = (await db())
    .input("id", sql.Int, id)
    .input("nome", sql.NVarChar(150), dados.nome)
    .input("email", sql.NVarChar(255), dados.email.trim().toLowerCase())
    .input("role", sql.VarChar(10), dados.role)
    .input("ativo", sql.Bit, dados.ativo);

  let setSenha = "";
  if (dados.senhaHash) {
    req.input("hash", sql.NVarChar(100), dados.senhaHash);
    setSenha = ", SenhaHash = @hash";
  }

  await req.query(`
    UPDATE dbo.Usuarios
       SET Nome = @nome, Email = @email, Role = @role, Ativo = @ativo, AtualizadoEm = SYSDATETIME()${setSenha}
     WHERE Id = @id
  `);
}

export async function contarAdminsAtivos(ignorarId?: number): Promise<number> {
  const r = await (await db())
    .input("id", sql.Int, ignorarId ?? 0)
    .query<{ Total: number }>(
      `SELECT COUNT(*) AS Total FROM dbo.Usuarios WHERE Role = 'admin' AND Ativo = 1 AND Id <> @id`,
    );
  return r.recordset[0].Total;
}
