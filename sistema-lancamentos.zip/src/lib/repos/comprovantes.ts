import "server-only";
import { db, getPool, sql } from "../db";
import type { Comprovante, HistoricoItem, LancamentoSap, StatusComprovante } from "../types";

const SELECT_COMPROVANTE = `
  SELECT c.Id, c.NumeroPedidoExterno, c.Cnpj, c.ValorComprovante, c.Status, c.DataEnvio, c.Observacao,
         c.UsuarioEnvioId, ue.Nome AS UsuarioEnvioNome,
         c.AprovadorId, ap.Nome AS AprovadorNome, c.DataDecisao, c.MotivoRejeicao, c.UltimoErroSap,
         a.NomeArquivo AS AnexoNome, a.MimeType AS AnexoMime
    FROM dbo.Comprovantes c
    JOIN dbo.Usuarios ue ON ue.Id = c.UsuarioEnvioId
    LEFT JOIN dbo.Usuarios ap ON ap.Id = c.AprovadorId
    LEFT JOIN dbo.ComprovanteAnexos a ON a.ComprovanteId = c.Id
`;

export async function criarComprovante(dados: {
  numeroPedidoExterno: string;
  cnpj: string;
  valor: number;
  observacao: string | null;
  usuarioId: number;
  anexo: { nome: string; mime: string; conteudo: Buffer };
}): Promise<number> {
  const pool = await getPool();
  const tx = new sql.Transaction(pool);
  await tx.begin();
  try {
    const ins = await new sql.Request(tx)
      .input("pedido", sql.NVarChar(100), dados.numeroPedidoExterno)
      .input("cnpj", sql.Char(14), dados.cnpj)
      .input("valor", sql.Decimal(19, 2), dados.valor)
      .input("obs", sql.NVarChar(1000), dados.observacao)
      .input("usuario", sql.Int, dados.usuarioId)
      .query<{ Id: number }>(`
        INSERT INTO dbo.Comprovantes (NumeroPedidoExterno, Cnpj, ValorComprovante, Observacao, UsuarioEnvioId)
        OUTPUT inserted.Id
        VALUES (@pedido, @cnpj, @valor, @obs, @usuario)
      `);
    const id = ins.recordset[0].Id;

    await new sql.Request(tx)
      .input("id", sql.Int, id)
      .input("nome", sql.NVarChar(255), dados.anexo.nome)
      .input("mime", sql.VarChar(100), dados.anexo.mime)
      .input("tamanho", sql.Int, dados.anexo.conteudo.length)
      .input("conteudo", sql.VarBinary(sql.MAX), dados.anexo.conteudo)
      .query(`
        INSERT INTO dbo.ComprovanteAnexos (ComprovanteId, NomeArquivo, MimeType, Tamanho, Conteudo)
        VALUES (@id, @nome, @mime, @tamanho, @conteudo)
      `);

    await inserirHistorico(new sql.Request(tx), id, dados.usuarioId, "ENVIADO", null);
    await tx.commit();
    return id;
  } catch (err) {
    await tx.rollback().catch(() => {});
    throw err;
  }
}

export interface FiltroComprovantes {
  usuarioId?: number; // quando informado, restringe aos comprovantes do usuário
  status?: StatusComprovante;
  busca?: string; // Nº pedido externo ou CNPJ
  pagina?: number;
  porPagina?: number;
}

export async function listarComprovantes(
  filtro: FiltroComprovantes,
): Promise<{ itens: Comprovante[]; total: number }> {
  const porPagina = filtro.porPagina ?? 20;
  const pagina = Math.max(1, filtro.pagina ?? 1);
  const req = await db();
  const where: string[] = [];

  if (filtro.usuarioId) {
    req.input("usuarioId", sql.Int, filtro.usuarioId);
    where.push("c.UsuarioEnvioId = @usuarioId");
  }
  if (filtro.status) {
    req.input("status", sql.VarChar(15), filtro.status);
    where.push("c.Status = @status");
  }
  if (filtro.busca?.trim()) {
    const busca = filtro.busca.trim();
    const digitos = busca.replace(/\D/g, "");
    req.input("busca", sql.NVarChar(110), `%${busca}%`);
    const cond = ["c.NumeroPedidoExterno LIKE @busca"];
    if (digitos.length >= 3) {
      req.input("buscaCnpj", sql.VarChar(20), `%${digitos}%`);
      cond.push("c.Cnpj LIKE @buscaCnpj");
    }
    where.push(`(${cond.join(" OR ")})`);
  }

  req.input("offset", sql.Int, (pagina - 1) * porPagina);
  req.input("fetch", sql.Int, porPagina);
  const whereSql = where.length ? `WHERE ${where.join(" AND ")}` : "";

  const r = await req.query(`
    SELECT COUNT(*) AS Total FROM dbo.Comprovantes c ${whereSql};
    ${SELECT_COMPROVANTE}
    ${whereSql}
    ORDER BY c.DataEnvio DESC, c.Id DESC
    OFFSET @offset ROWS FETCH NEXT @fetch ROWS ONLY;
  `);

  const sets = r.recordsets as unknown as [{ Total: number }[], Comprovante[]];
  return { total: sets[0][0].Total, itens: sets[1] };
}

export async function obterComprovante(id: number): Promise<Comprovante | null> {
  const r = await (await db())
    .input("id", sql.Int, id)
    .query<Comprovante>(`${SELECT_COMPROVANTE} WHERE c.Id = @id`);
  return r.recordset[0] ?? null;
}

export async function obterAnexo(
  id: number,
): Promise<{ NomeArquivo: string; MimeType: string; Conteudo: Buffer; UsuarioEnvioId: number } | null> {
  const r = await (await db()).input("id", sql.Int, id).query(`
    SELECT a.NomeArquivo, a.MimeType, a.Conteudo, c.UsuarioEnvioId
      FROM dbo.ComprovanteAnexos a
      JOIN dbo.Comprovantes c ON c.Id = a.ComprovanteId
     WHERE a.ComprovanteId = @id
  `);
  return r.recordset[0] ?? null;
}

export async function listarHistorico(id: number): Promise<HistoricoItem[]> {
  const r = await (await db()).input("id", sql.Int, id).query<HistoricoItem>(`
    SELECT h.Id, h.Acao, h.Detalhe, h.CriadoEm, u.Nome AS UsuarioNome
      FROM dbo.ComprovanteHistorico h
      LEFT JOIN dbo.Usuarios u ON u.Id = h.UsuarioId
     WHERE h.ComprovanteId = @id
     ORDER BY h.CriadoEm, h.Id
  `);
  return r.recordset;
}

export async function listarLancamentos(id: number): Promise<LancamentoSap[]> {
  const r = await (await db()).input("id", sql.Int, id).query<LancamentoSap>(`
    SELECT Id, PagamentoDocEntry, PagamentoDocNum, CardCode, NotaDocEntry, NotaDocNum, Parcela, ValorAplicado, CriadoEm
      FROM dbo.ComprovanteLancamentos
     WHERE ComprovanteId = @id
     ORDER BY PagamentoDocEntry, NotaDocEntry, Parcela
  `);
  return r.recordset;
}

/**
 * Trava o comprovante para processamento (PENDENTE/ERRO -> PROCESSANDO).
 * Retorna false se outro admin já estiver processando ou se o status não permitir.
 */
export async function travarParaProcessamento(id: number, adminId: number): Promise<boolean> {
  const r = await (await db())
    .input("id", sql.Int, id)
    .input("admin", sql.Int, adminId)
    .query(`
      UPDATE dbo.Comprovantes
         SET Status = 'PROCESSANDO', AprovadorId = @admin, UltimoErroSap = NULL
       WHERE Id = @id AND Status IN ('PENDENTE', 'ERRO')
    `);
  return r.rowsAffected[0] === 1;
}

export interface LancamentoNovo {
  pagamentoDocEntry: number;
  pagamentoDocNum: number | null;
  cardCode: string;
  notaDocEntry: number;
  notaDocNum: number | null;
  parcela: number;
  valorAplicado: number;
}

export async function concluirAprovacao(
  id: number,
  adminId: number,
  lancamentos: LancamentoNovo[],
  detalhe: string,
): Promise<void> {
  const pool = await getPool();
  const tx = new sql.Transaction(pool);
  await tx.begin();
  try {
    for (const l of lancamentos) {
      await new sql.Request(tx)
        .input("id", sql.Int, id)
        .input("pagEntry", sql.Int, l.pagamentoDocEntry)
        .input("pagNum", sql.Int, l.pagamentoDocNum)
        .input("cardCode", sql.NVarChar(50), l.cardCode)
        .input("notaEntry", sql.Int, l.notaDocEntry)
        .input("notaNum", sql.Int, l.notaDocNum)
        .input("parcela", sql.Int, l.parcela)
        .input("valor", sql.Decimal(19, 2), l.valorAplicado)
        .query(`
          INSERT INTO dbo.ComprovanteLancamentos
            (ComprovanteId, PagamentoDocEntry, PagamentoDocNum, CardCode, NotaDocEntry, NotaDocNum, Parcela, ValorAplicado)
          VALUES (@id, @pagEntry, @pagNum, @cardCode, @notaEntry, @notaNum, @parcela, @valor)
        `);
    }

    await new sql.Request(tx)
      .input("id", sql.Int, id)
      .input("admin", sql.Int, adminId)
      .query(`
        UPDATE dbo.Comprovantes
           SET Status = 'APROVADO', AprovadorId = @admin, DataDecisao = SYSDATETIME(), UltimoErroSap = NULL
         WHERE Id = @id
      `);

    await inserirHistorico(new sql.Request(tx), id, adminId, "APROVADO", detalhe);
    await tx.commit();
  } catch (err) {
    await tx.rollback().catch(() => {});
    throw err;
  }
}

export async function registrarErroSap(id: number, adminId: number, mensagem: string): Promise<void> {
  const pool = await getPool();
  const tx = new sql.Transaction(pool);
  await tx.begin();
  try {
    await new sql.Request(tx)
      .input("id", sql.Int, id)
      .input("msg", sql.NVarChar(2000), mensagem.slice(0, 2000))
      .query(`UPDATE dbo.Comprovantes SET Status = 'ERRO', UltimoErroSap = @msg WHERE Id = @id`);
    await inserirHistorico(new sql.Request(tx), id, adminId, "ERRO_SAP", mensagem);
    await tx.commit();
  } catch (err) {
    await tx.rollback().catch(() => {});
    throw err;
  }
}

/** Libera um comprovante preso em PROCESSANDO (ex.: queda do servidor no meio da baixa). */
export async function destravarComprovante(id: number, adminId: number): Promise<boolean> {
  const pool = await getPool();
  const tx = new sql.Transaction(pool);
  await tx.begin();
  try {
    const msg = "Processamento interrompido. Confira no SAP se o Contas a Receber foi gerado antes de reprocessar.";
    const r = await new sql.Request(tx)
      .input("id", sql.Int, id)
      .input("msg", sql.NVarChar(2000), msg)
      .query(`UPDATE dbo.Comprovantes SET Status = 'ERRO', UltimoErroSap = @msg WHERE Id = @id AND Status = 'PROCESSANDO'`);
    if (r.rowsAffected[0] !== 1) {
      await tx.rollback();
      return false;
    }
    await inserirHistorico(new sql.Request(tx), id, adminId, "DESTRAVADO", msg);
    await tx.commit();
    return true;
  } catch (err) {
    await tx.rollback().catch(() => {});
    throw err;
  }
}

export async function rejeitarComprovante(id: number, adminId: number, motivo: string): Promise<boolean> {
  const pool = await getPool();
  const tx = new sql.Transaction(pool);
  await tx.begin();
  try {
    const r = await new sql.Request(tx)
      .input("id", sql.Int, id)
      .input("admin", sql.Int, adminId)
      .input("motivo", sql.NVarChar(1000), motivo)
      .query(`
        UPDATE dbo.Comprovantes
           SET Status = 'REJEITADO', AprovadorId = @admin, DataDecisao = SYSDATETIME(), MotivoRejeicao = @motivo
         WHERE Id = @id AND Status IN ('PENDENTE', 'ERRO')
      `);
    if (r.rowsAffected[0] !== 1) {
      await tx.rollback();
      return false;
    }
    await inserirHistorico(new sql.Request(tx), id, adminId, "REJEITADO", motivo);
    await tx.commit();
    return true;
  } catch (err) {
    await tx.rollback().catch(() => {});
    throw err;
  }
}

export async function contarPorStatus(usuarioId?: number): Promise<Record<StatusComprovante, number>> {
  const req = await db();
  let where = "";
  if (usuarioId) {
    req.input("usuarioId", sql.Int, usuarioId);
    where = "WHERE UsuarioEnvioId = @usuarioId";
  }
  const r = await req.query<{ Status: StatusComprovante; Total: number }>(
    `SELECT Status, COUNT(*) AS Total FROM dbo.Comprovantes ${where} GROUP BY Status`,
  );
  const base: Record<StatusComprovante, number> = { PENDENTE: 0, PROCESSANDO: 0, APROVADO: 0, REJEITADO: 0, ERRO: 0 };
  for (const row of r.recordset) base[row.Status] = row.Total;
  return base;
}

function inserirHistorico(
  req: sql.Request,
  comprovanteId: number,
  usuarioId: number | null,
  acao: string,
  detalhe: string | null,
) {
  return req
    .input("hId", sql.Int, comprovanteId)
    .input("hUsuario", sql.Int, usuarioId)
    .input("hAcao", sql.VarChar(30), acao)
    .input("hDetalhe", sql.NVarChar(2000), detalhe?.slice(0, 2000) ?? null)
    .query(`
      INSERT INTO dbo.ComprovanteHistorico (ComprovanteId, UsuarioId, Acao, Detalhe)
      VALUES (@hId, @hUsuario, @hAcao, @hDetalhe)
    `);
}
