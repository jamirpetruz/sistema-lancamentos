import "server-only";

// Limitador simples em memória (por instância). Suficiente para frear força bruta no login.
const tentativas = new Map<string, { count: number; resetEm: number }>();

export function excedeuLimite(chave: string, max = 5): boolean {
  const agora = Date.now();
  const reg = tentativas.get(chave);
  if (!reg || reg.resetEm < agora) return false;
  return reg.count >= max;
}

export function registrarFalha(chave: string, janelaMs = 15 * 60_000): void {
  const agora = Date.now();
  const reg = tentativas.get(chave);
  if (!reg || reg.resetEm < agora) tentativas.set(chave, { count: 1, resetEm: agora + janelaMs });
  else reg.count++;
}

export function limparFalhas(chave: string): void {
  tentativas.delete(chave);
}
