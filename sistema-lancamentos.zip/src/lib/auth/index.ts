import "server-only";
import { cache } from "react";
import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { obterUsuario } from "../repos/usuarios";
import type { Usuario } from "../types";
import { SESSION_COOKIE, assinarSessao, sessionHours, verificarSessao } from "./session";

/**
 * Usuário da sessão atual, revalidado no banco a cada requisição
 * (usuário desativado ou com role alterada perde o acesso imediatamente).
 */
export const usuarioAtual = cache(async (): Promise<Usuario | null> => {
  const store = await cookies();
  const sessao = await verificarSessao(store.get(SESSION_COOKIE)?.value);
  if (!sessao) return null;
  const usuario = await obterUsuario(Number(sessao.sub));
  if (!usuario || !usuario.Ativo) return null;
  return usuario;
});

export async function exigirUsuario(): Promise<Usuario> {
  const usuario = await usuarioAtual();
  if (!usuario) redirect("/login");
  return usuario;
}

export async function exigirAdmin(): Promise<Usuario> {
  const usuario = await exigirUsuario();
  if (usuario.Role !== "admin") redirect("/comprovantes");
  return usuario;
}

export async function iniciarSessao(usuario: Usuario): Promise<void> {
  const token = await assinarSessao({ sub: String(usuario.Id), nome: usuario.Nome, role: usuario.Role });
  const store = await cookies();
  store.set(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.AUTH_COOKIE_SECURE === "true",
    path: "/",
    maxAge: sessionHours() * 3600,
  });
}

export async function encerrarSessao(): Promise<void> {
  (await cookies()).delete(SESSION_COOKIE);
}
