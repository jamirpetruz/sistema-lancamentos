// Assinatura/verificação do token de sessão (JWT HS256).
// Sem dependências de Node: é usado também pelo middleware (Edge runtime).
import { SignJWT, jwtVerify } from "jose";
import type { Role } from "../types";

export const SESSION_COOKIE = "sl_session";

export interface SessionPayload {
  sub: string; // Id do usuário
  nome: string;
  role: Role;
}

function secretKey(): Uint8Array {
  const secret = process.env.AUTH_SECRET;
  if (!secret || secret.length < 32) {
    throw new Error("AUTH_SECRET não configurado (mínimo de 32 caracteres).");
  }
  return new TextEncoder().encode(secret);
}

export function sessionHours(): number {
  const h = Number(process.env.AUTH_SESSION_HOURS || 8);
  return Number.isFinite(h) && h > 0 ? h : 8;
}

export async function assinarSessao(payload: SessionPayload): Promise<string> {
  return new SignJWT({ nome: payload.nome, role: payload.role })
    .setProtectedHeader({ alg: "HS256" })
    .setSubject(payload.sub)
    .setIssuedAt()
    .setExpirationTime(`${sessionHours()}h`)
    .sign(secretKey());
}

export async function verificarSessao(token: string | undefined): Promise<SessionPayload | null> {
  if (!token) return null;
  try {
    const { payload } = await jwtVerify(token, secretKey(), { algorithms: ["HS256"] });
    if (!payload.sub || (payload.role !== "admin" && payload.role !== "user")) return null;
    return { sub: payload.sub, nome: String(payload.nome ?? ""), role: payload.role };
  } catch {
    return null;
  }
}
