import "server-only";
import sql from "mssql";
import { dbEnv } from "./env";

export { sql };

const globalForDb = globalThis as unknown as { __mssqlPool?: Promise<sql.ConnectionPool> };

function createPool(): Promise<sql.ConnectionPool> {
  const env = dbEnv();
  const pool = new sql.ConnectionPool({
    server: env.server,
    port: env.port,
    database: env.database,
    user: env.user,
    password: env.password,
    options: {
      encrypt: env.encrypt,
      trustServerCertificate: env.trustServerCertificate,
    },
    pool: { max: 10, min: 0, idleTimeoutMillis: 30_000 },
  });

  pool.on("error", (err) => {
    console.error("[db] erro no pool:", err);
  });

  return pool.connect().catch((err) => {
    // Permite nova tentativa na próxima requisição
    globalForDb.__mssqlPool = undefined;
    throw err;
  });
}

/** Pool único por processo (sobrevive ao hot reload em dev). */
export function getPool(): Promise<sql.ConnectionPool> {
  if (!globalForDb.__mssqlPool) globalForDb.__mssqlPool = createPool();
  return globalForDb.__mssqlPool;
}

/** Atalho para criar um Request parametrizado. */
export async function db(): Promise<sql.Request> {
  return (await getPool()).request();
}
