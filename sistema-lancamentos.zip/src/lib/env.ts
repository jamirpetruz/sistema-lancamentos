import "server-only";

function required(name: string): string {
  const value = process.env[name];
  if (!value) throw new Error(`Variável de ambiente ${name} não configurada.`);
  return value;
}

export const dbEnv = () => ({
  server: required("DB_SERVER"),
  port: Number(process.env.DB_PORT || 1433),
  database: required("DB_DATABASE"),
  user: required("DB_USER"),
  password: process.env.DB_PASSWORD ?? "",
  encrypt: process.env.DB_ENCRYPT === "true",
  trustServerCertificate: process.env.DB_TRUST_SERVER_CERTIFICATE !== "false",
});

export const sapEnv = () => {
  const udf = required("SAP_UDF_PEDIDO_EXTERNO");
  // O nome do UDF entra no $filter do OData; só aceitamos identificadores válidos
  if (!/^U_[A-Za-z0-9_]+$/.test(udf)) {
    throw new Error("SAP_UDF_PEDIDO_EXTERNO deve começar com U_ e conter apenas letras, números e _.");
  }
  return {
    url: required("SAP_SL_URL").replace(/\/+$/, ""),
    companyDb: required("SAP_COMPANY_DB"),
    user: required("SAP_USER"),
    password: required("SAP_PASSWORD"),
    ignoreTls: process.env.SAP_SL_IGNORE_TLS === "true",
    udfPedidoExterno: udf,
    contaTransferencia: required("SAP_CONTA_TRANSFERENCIA"),
    validarCnpj: process.env.SAP_VALIDAR_CNPJ !== "false",
  };
};
