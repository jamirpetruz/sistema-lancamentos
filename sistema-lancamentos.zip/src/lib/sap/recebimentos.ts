import "server-only";
import { sapEnv } from "../env";
import { centavos, somenteDigitos } from "../format";
import { odataQuery, odataString, slGetAll, slRequest, SapError } from "./service-layer";

// ---------------------------------------------------------------- Tipos SAP

interface SlParcela {
  InstallmentId: number;
  DueDate: string;
  Total: number;
}

interface SlNota {
  DocEntry: number;
  DocNum: number;
  CardCode: string;
  CardName: string;
  DocDate: string;
  DocDueDate: string;
  DocTotal: number;
  PaidToDate: number;
  DocumentStatus: "bost_Open" | "bost_Close" | string;
  Cancelled?: "tYES" | "tNO";
  CancelStatus?: string;
  BPL_IDAssignedToInvoice?: number | null;
  DocumentInstallments?: SlParcela[];
}

interface SlPedido {
  DocEntry: number;
  DocNum: number;
  CardCode: string;
  CardName: string;
  DocDate: string;
  DocDueDate: string;
  DocTotal: number;
  DocumentStatus: string;
  Cancelled?: "tYES" | "tNO";
}

// ---------------------------------------------------------------- Tipos do app

export interface ParcelaAberta {
  /** Chave única "DocEntry-InstallmentId" */
  chave: string;
  docEntry: number;
  docNum: number;
  parcela: number;
  totalParcelas: number;
  vencimento: string;
  valorAberto: number;
  cardCode: string;
  bplId: number | null;
}

export interface NotaResumo {
  docEntry: number;
  docNum: number;
  cardCode: string;
  cardName: string;
  docDate: string;
  docDueDate: string;
  docTotal: number;
  paidToDate: number;
  saldo: number;
  aberta: boolean;
  bplId: number | null;
}

export interface PedidoResumo {
  docEntry: number;
  docNum: number;
  cardCode: string;
  cardName: string;
  docDate: string;
  docTotal: number;
  status: string;
}

export interface ClienteCnpj {
  cardCode: string;
  cardName: string;
  cnpjs: string[];
  confere: boolean;
}

export interface ConsultaPedidoExterno {
  pedidos: PedidoResumo[];
  notas: NotaResumo[];
  parcelas: ParcelaAberta[];
  totalAberto: number;
  clientes: ClienteCnpj[];
  cnpjConfere: boolean;
}

export interface Alocacao {
  chave: string;
  valor: number;
}

// ---------------------------------------------------------------- Consultas

/** Busca Pedidos de Venda, Notas Fiscais de Saída e parcelas em aberto vinculados ao Nº do Pedido Externo. */
export async function consultarPedidoExterno(pedidoExterno: string, cnpj: string): Promise<ConsultaPedidoExterno> {
  const env = sapEnv();
  const filtro = `${env.udfPedidoExterno} eq ${odataString(pedidoExterno)}`;

  const [notasSl, pedidosSl] = await Promise.all([
    slGetAll<SlNota>(
      odataQuery("Invoices", {
        $filter: filtro,
        $select:
          "DocEntry,DocNum,CardCode,CardName,DocDate,DocDueDate,DocTotal,PaidToDate,DocumentStatus,Cancelled,CancelStatus,BPL_IDAssignedToInvoice,DocumentInstallments",
        $orderby: "DocDueDate,DocEntry",
      }),
    ),
    slGetAll<SlPedido>(
      odataQuery("Orders", {
        $filter: filtro,
        $select: "DocEntry,DocNum,CardCode,CardName,DocDate,DocDueDate,DocTotal,DocumentStatus,Cancelled",
        $orderby: "DocEntry",
      }),
    ),
  ]);

  // Ignora notas canceladas e os documentos de cancelamento
  const notasValidas = notasSl.filter(
    (n) => n.Cancelled !== "tYES" && (!n.CancelStatus || n.CancelStatus === "csNo"),
  );

  const notas: NotaResumo[] = notasValidas.map((n) => {
    const aberta = n.DocumentStatus === "bost_Open";
    const saldo = aberta ? Math.max(0, centavos(n.DocTotal) - centavos(n.PaidToDate)) / 100 : 0;
    return {
      docEntry: n.DocEntry,
      docNum: n.DocNum,
      cardCode: n.CardCode,
      cardName: n.CardName,
      docDate: n.DocDate,
      docDueDate: n.DocDueDate,
      docTotal: n.DocTotal,
      paidToDate: n.PaidToDate,
      saldo,
      aberta,
      bplId: n.BPL_IDAssignedToInvoice ?? null,
    };
  });

  const parcelas = notasValidas
    .filter((n) => n.DocumentStatus === "bost_Open")
    .flatMap(parcelasEmAberto)
    .sort(
      (a, b) =>
        a.vencimento.localeCompare(b.vencimento) || a.docEntry - b.docEntry || a.parcela - b.parcela,
    );

  const totalAberto = parcelas.reduce((s, p) => s + centavos(p.valorAberto), 0) / 100;

  const pedidos: PedidoResumo[] = pedidosSl
    .filter((p) => p.Cancelled !== "tYES")
    .map((p) => ({
      docEntry: p.DocEntry,
      docNum: p.DocNum,
      cardCode: p.CardCode,
      cardName: p.CardName,
      docDate: p.DocDate,
      docTotal: p.DocTotal,
      status: p.DocumentStatus === "bost_Open" ? "Aberto" : "Fechado",
    }));

  const cardCodes = [...new Set([...notas.map((n) => n.cardCode), ...pedidos.map((p) => p.cardCode)])];
  const clientes = await Promise.all(cardCodes.map((c) => consultarCnpjCliente(c, cnpj)));
  const cnpjConfere = clientes.length > 0 && clientes.every((c) => c.confere);

  return { pedidos, notas, parcelas, totalAberto, clientes, cnpjConfere };
}

/**
 * Distribui o saldo pago entre as parcelas, em ordem, para descobrir o valor em aberto de cada uma.
 * (O Service Layer não expõe o valor pago por parcela; o SAP baixa parcelas em ordem de vencimento.)
 */
function parcelasEmAberto(n: SlNota): ParcelaAberta[] {
  const base = {
    docEntry: n.DocEntry,
    docNum: n.DocNum,
    cardCode: n.CardCode,
    bplId: n.BPL_IDAssignedToInvoice ?? null,
  };
  const saldoNota = centavos(n.DocTotal) - centavos(n.PaidToDate);
  const lista = [...(n.DocumentInstallments ?? [])].sort((a, b) => a.InstallmentId - b.InstallmentId);
  const somaParcelas = lista.reduce((s, p) => s + centavos(p.Total), 0);

  // Parcela única (ou dados de parcelas inconsistentes): trata a nota inteira como parcela 1
  if (lista.length <= 1 || Math.abs(somaParcelas - centavos(n.DocTotal)) > 5) {
    if (saldoNota <= 0) return [];
    return [
      {
        ...base,
        chave: `${n.DocEntry}-1`,
        parcela: lista[0]?.InstallmentId ?? 1,
        totalParcelas: 1,
        vencimento: (lista[0]?.DueDate ?? n.DocDueDate).slice(0, 10),
        valorAberto: saldoNota / 100,
      },
    ];
  }

  let pagoRestante = centavos(n.PaidToDate);
  const result: ParcelaAberta[] = [];
  for (const p of lista) {
    const total = centavos(p.Total);
    const pagoAqui = Math.min(total, Math.max(0, pagoRestante));
    pagoRestante -= pagoAqui;
    const aberto = total - pagoAqui;
    if (aberto > 0) {
      result.push({
        ...base,
        chave: `${n.DocEntry}-${p.InstallmentId}`,
        parcela: p.InstallmentId,
        totalParcelas: lista.length,
        vencimento: p.DueDate.slice(0, 10),
        valorAberto: aberto / 100,
      });
    }
  }
  return result;
}

async function consultarCnpjCliente(cardCode: string, cnpj: string): Promise<ClienteCnpj> {
  const bp = await slRequest<{
    CardCode: string;
    CardName: string;
    FederalTaxID?: string | null;
    BPFiscalTaxIDCollection?: { TaxId0?: string | null }[];
  }>(
    "GET",
    odataQuery(`BusinessPartners(${odataString(cardCode)})`, {
      $select: "CardCode,CardName,FederalTaxID,BPFiscalTaxIDCollection",
    }),
  );

  // Localização Brasil: CNPJ fica em BPFiscalTaxIDCollection.TaxId0 (CRD7); FederalTaxID como alternativa
  const cnpjs = [
    ...new Set(
      [bp.FederalTaxID, ...(bp.BPFiscalTaxIDCollection ?? []).map((f) => f.TaxId0)]
        .map((v) => somenteDigitos(v ?? ""))
        .filter((v) => v.length === 14),
    ),
  ];
  return { cardCode: bp.CardCode, cardName: bp.CardName, cnpjs, confere: cnpjs.includes(cnpj) };
}

/** Sugestão de baixa: aplica o valor do comprovante nas parcelas por ordem de vencimento. */
export function sugerirAlocacao(parcelas: ParcelaAberta[], valor: number): Alocacao[] {
  let restante = centavos(valor);
  return parcelas.map((p) => {
    const aplicar = Math.min(restante, centavos(p.valorAberto));
    restante -= aplicar;
    return { chave: p.chave, valor: aplicar / 100 };
  });
}

// ---------------------------------------------------------------- Baixa

export interface PagamentoCriado {
  docEntry: number;
  docNum: number | null;
  cardCode: string;
  itens: { docEntry: number; docNum: number; parcela: number; valor: number }[];
}

/** Marcador gravado no início das Observações do Contas a Receber (usado para evitar baixa duplicada). */
export function marcadorComprovante(comprovanteId: number): string {
  return `SLC#${comprovanteId}|`;
}

/** Retorna pagamentos não cancelados já lançados no SAP para o comprovante. */
export async function pagamentosExistentes(comprovanteId: number): Promise<{ DocEntry: number; DocNum: number }[]> {
  return slGetAll<{ DocEntry: number; DocNum: number }>(
    odataQuery("IncomingPayments", {
      $filter: `startswith(Remarks, ${odataString(marcadorComprovante(comprovanteId))}) and Cancelled eq 'tNO'`,
      $select: "DocEntry,DocNum",
    }),
  );
}

/**
 * Valida as alocações contra o saldo atual do SAP e cria o(s) Contas a Receber (IncomingPayments).
 * Gera um pagamento por cliente/filial. Se algum falhar, cancela os já criados.
 */
export async function lancarBaixa(params: {
  comprovanteId: number;
  pedidoExterno: string;
  cnpj: string;
  valorComprovante: number;
  dataLancamento: string; // YYYY-MM-DD
  alocacoes: Alocacao[];
}): Promise<PagamentoCriado[]> {
  const env = sapEnv();
  const consulta = await consultarPedidoExterno(params.pedidoExterno, params.cnpj);

  if (env.validarCnpj && !consulta.cnpjConfere) {
    throw new SapError("O CNPJ do comprovante não corresponde ao cliente das notas fiscais no SAP.", 422);
  }

  const parcelasPorChave = new Map(consulta.parcelas.map((p) => [p.chave, p]));
  const usados = params.alocacoes.filter((a) => centavos(a.valor) > 0);

  if (usados.length === 0) throw new SapError("Informe ao menos uma parcela para baixa.", 422);

  let soma = 0;
  for (const a of usados) {
    const p = parcelasPorChave.get(a.chave);
    if (!p) throw new SapError(`Parcela ${a.chave} não está mais em aberto no SAP.`, 409);
    if (centavos(a.valor) > centavos(p.valorAberto)) {
      throw new SapError(
        `Valor aplicado na NF ${p.docNum} parcela ${p.parcela} excede o saldo em aberto (${p.valorAberto.toFixed(2)}).`,
        409,
      );
    }
    soma += centavos(a.valor);
  }
  if (soma !== centavos(params.valorComprovante)) {
    throw new SapError(
      `A soma aplicada (${(soma / 100).toFixed(2)}) deve ser igual ao valor do comprovante (${params.valorComprovante.toFixed(2)}).`,
      422,
    );
  }

  const existentes = await pagamentosExistentes(params.comprovanteId);
  if (existentes.length > 0) {
    throw new SapError(
      `Já existe(m) Contas a Receber no SAP para este comprovante (DocNum ${existentes
        .map((e) => e.DocNum)
        .join(", ")}). Verifique antes de reprocessar.`,
      409,
    );
  }

  // Agrupa por cliente + filial (um IncomingPayment só pode ter um cliente e uma filial)
  const grupos = new Map<string, { cardCode: string; bplId: number | null; itens: { p: ParcelaAberta; valor: number }[] }>();
  for (const a of usados) {
    const p = parcelasPorChave.get(a.chave)!;
    const k = `${p.cardCode}|${p.bplId ?? ""}`;
    if (!grupos.has(k)) grupos.set(k, { cardCode: p.cardCode, bplId: p.bplId, itens: [] });
    grupos.get(k)!.itens.push({ p, valor: centavos(a.valor) / 100 });
  }

  const marcador = marcadorComprovante(params.comprovanteId);
  const criados: PagamentoCriado[] = [];

  try {
    for (const g of grupos.values()) {
      const total = g.itens.reduce((s, i) => s + centavos(i.valor), 0) / 100;
      const corpo: Record<string, unknown> = {
        DocType: "rCustomer",
        CardCode: g.cardCode,
        DocDate: params.dataLancamento,
        TaxDate: params.dataLancamento,
        DueDate: params.dataLancamento,
        TransferAccount: env.contaTransferencia,
        TransferSum: total,
        TransferDate: params.dataLancamento,
        TransferReference: params.pedidoExterno.slice(0, 27),
        Remarks: `${marcador} Comprovante ${params.comprovanteId} - Pedido Externo ${params.pedidoExterno}`.slice(0, 254),
        JournalRemarks: `Receb. Pedido ${params.pedidoExterno}`.slice(0, 50),
        PaymentInvoices: g.itens.map((i) => ({
          DocEntry: i.p.docEntry,
          InvoiceType: "it_Invoice",
          InstallmentId: i.p.parcela,
          SumApplied: i.valor,
        })),
      };
      if (g.bplId != null) corpo.BPLID = g.bplId;

      const res = await slRequest<{ DocEntry: number; DocNum?: number }>("POST", "IncomingPayments", corpo);
      criados.push({
        docEntry: res.DocEntry,
        docNum: res.DocNum ?? null,
        cardCode: g.cardCode,
        itens: g.itens.map((i) => ({ docEntry: i.p.docEntry, docNum: i.p.docNum, parcela: i.p.parcela, valor: i.valor })),
      });
    }
  } catch (err) {
    // Compensação: cancela pagamentos já criados neste processamento
    const falhasCancelamento: number[] = [];
    for (const c of criados) {
      try {
        await slRequest("POST", `IncomingPayments(${c.docEntry})/Cancel`);
      } catch {
        falhasCancelamento.push(c.docNum ?? c.docEntry);
      }
    }
    const msg = err instanceof Error ? err.message : String(err);
    const extra = falhasCancelamento.length
      ? ` ATENÇÃO: não foi possível cancelar os Contas a Receber ${falhasCancelamento.join(", ")}; cancele-os manualmente no SAP.`
      : criados.length
        ? " Os lançamentos parciais foram cancelados."
        : "";
    throw new SapError(msg + extra, err instanceof SapError ? err.status : 500);
  }

  return criados;
}
