import "server-only";
import { Agent, fetch, type Dispatcher } from "undici";
import { sapEnv } from "../env";

/** Erro retornado pelo Service Layer, com a mensagem original do SAP. */
export class SapError extends Error {
  constructor(
    message: string,
    public readonly status: number,
    public readonly code?: string | number,
  ) {
    super(message);
    this.name = "SapError";
  }
}

interface SessaoSl {
  cookie: string;
  expiraEm: number;
}

const globalForSl = globalThis as unknown as {
  __slSessao?: SessaoSl;
  __slLogin?: Promise<SessaoSl>;
  __slAgent?: Dispatcher;
};

function dispatcher(): Dispatcher | undefined {
  const env = sapEnv();
  if (!env.ignoreTls) return undefined;
  if (!globalForSl.__slAgent) {
    globalForSl.__slAgent = new Agent({ connect: { rejectUnauthorized: false } });
  }
  return globalForSl.__slAgent;
}

async function login(): Promise<SessaoSl> {
  const env = sapEnv();
  const res = await fetch(`${env.url}/Login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ CompanyDB: env.companyDb, UserName: env.user, Password: env.password }),
    dispatcher: dispatcher(),
  });

  if (!res.ok) throw await erroDaResposta(res, "Falha no login do Service Layer");

  const body = (await res.json()) as { SessionTimeout?: number };
  // B1SESSION + ROUTEID (este último existe quando há load balancer)
  const cookie = res.headers
    .getSetCookie()
    .map((c) => c.split(";")[0])
    .filter((c) => c.startsWith("B1SESSION=") || c.startsWith("ROUTEID="))
    .join("; ");

  if (!cookie.includes("B1SESSION=")) {
    throw new SapError("Service Layer não retornou o cookie B1SESSION.", res.status);
  }

  const timeoutMin = body.SessionTimeout ?? 30;
  // renova um minuto antes de expirar
  return { cookie, expiraEm: Date.now() + Math.max(1, timeoutMin - 1) * 60_000 };
}

async function obterSessao(forcarNovo = false): Promise<SessaoSl> {
  const atual = globalForSl.__slSessao;
  if (!forcarNovo && atual && atual.expiraEm > Date.now()) return atual;

  // Evita logins concorrentes
  if (!globalForSl.__slLogin) {
    globalForSl.__slLogin = login()
      .then((s) => {
        globalForSl.__slSessao = s;
        return s;
      })
      .finally(() => {
        globalForSl.__slLogin = undefined;
      });
  }
  return globalForSl.__slLogin;
}

async function erroDaResposta(res: Awaited<ReturnType<typeof fetch>>, prefixo: string): Promise<SapError> {
  const texto = await res.text().catch(() => "");
  let mensagem = texto || res.statusText;
  let code: string | number | undefined;
  try {
    const json = JSON.parse(texto) as {
      error?: { code?: string | number; message?: string | { value?: string } };
    };
    if (json.error) {
      code = json.error.code;
      const m = json.error.message;
      mensagem = typeof m === "string" ? m : (m?.value ?? mensagem);
    }
  } catch {
    // resposta não-JSON: mantém o texto bruto
  }
  return new SapError(`${prefixo}: ${mensagem}`, res.status, code);
}

type Metodo = "GET" | "POST" | "PATCH" | "DELETE";

/**
 * Requisição autenticada ao Service Layer.
 * `caminho` é relativo à URL base (ex.: "Invoices?$filter=...").
 * Refaz o login automaticamente uma vez se a sessão expirar (401).
 */
export async function slRequest<T = unknown>(metodo: Metodo, caminho: string, corpo?: unknown): Promise<T> {
  const env = sapEnv();
  const url = caminho.startsWith("http") ? caminho : `${env.url}/${caminho.replace(/^\/+/, "")}`;

  for (let tentativa = 0; tentativa < 2; tentativa++) {
    const sessao = await obterSessao(tentativa > 0);
    const res = await fetch(url, {
      method: metodo,
      headers: {
        Cookie: sessao.cookie,
        "Content-Type": "application/json",
        Prefer: "odata.maxpagesize=100",
      },
      body: corpo === undefined ? undefined : JSON.stringify(corpo),
      dispatcher: dispatcher(),
    });

    if (res.status === 401 && tentativa === 0) {
      globalForSl.__slSessao = undefined;
      continue;
    }
    if (!res.ok) throw await erroDaResposta(res, `SAP ${metodo} ${caminho.split("?")[0]}`);
    if (res.status === 204) return undefined as T;

    const texto = await res.text();
    return (texto ? JSON.parse(texto) : undefined) as T;
  }
  throw new SapError("Não foi possível autenticar no Service Layer.", 401);
}

/** GET em coleção seguindo a paginação (odata.nextLink / @odata.nextLink). */
export async function slGetAll<T>(caminho: string): Promise<T[]> {
  const env = sapEnv();
  const itens: T[] = [];
  let proximo: string | undefined = caminho;
  let paginas = 0;

  while (proximo && paginas < 50) {
    const pagina: { value: T[]; "odata.nextLink"?: string; "@odata.nextLink"?: string } = await slRequest(
      "GET",
      proximo,
    );
    itens.push(...pagina.value);
    const next = pagina["odata.nextLink"] ?? pagina["@odata.nextLink"];
    // nextLink vem relativo à raiz do serviço (ex.: "Invoices?$skip=100&...") ou absoluto
    proximo = next ? (next.startsWith("http") || next.startsWith("/") ? new URL(next, env.url + "/").toString() : next) : undefined;
    paginas++;
  }
  return itens;
}

/** Escapa um literal string para uso em $filter OData. */
export function odataString(valor: string): string {
  return `'${valor.replace(/'/g, "''")}'`;
}

/** Monta "Entidade?$filter=...&$select=..." com encoding correto. */
export function odataQuery(entidade: string, params: Record<string, string | undefined>): string {
  const qs = Object.entries(params)
    .filter(([, v]) => v !== undefined && v !== "")
    .map(([k, v]) => `${k}=${encodeURIComponent(v as string)}`)
    .join("&");
  return qs ? `${entidade}?${qs}` : entidade;
}
