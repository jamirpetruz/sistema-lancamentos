export function somenteDigitos(valor: string): string {
  return valor.replace(/\D/g, "");
}

export function cnpjValido(valor: string): boolean {
  const cnpj = somenteDigitos(valor);
  if (cnpj.length !== 14 || /^(\d)\1{13}$/.test(cnpj)) return false;

  const calc = (base: string) => {
    const pesos = base.length === 12 ? [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2] : [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2];
    const soma = base.split("").reduce((acc, d, i) => acc + Number(d) * pesos[i], 0);
    const resto = soma % 11;
    return resto < 2 ? 0 : 11 - resto;
  };

  const d1 = calc(cnpj.slice(0, 12));
  const d2 = calc(cnpj.slice(0, 12) + d1);
  return cnpj.endsWith(`${d1}${d2}`);
}

export function formatarCnpj(valor: string): string {
  const c = somenteDigitos(valor);
  if (c.length !== 14) return valor;
  return c.replace(/^(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})$/, "$1.$2.$3/$4-$5");
}

const moeda = new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" });
export function formatarMoeda(valor: number): string {
  return moeda.format(valor);
}

const dataHora = new Intl.DateTimeFormat("pt-BR", {
  dateStyle: "short",
  timeStyle: "short",
  timeZone: "America/Sao_Paulo",
});
export function formatarDataHora(valor: Date | string | null | undefined): string {
  if (!valor) return "-";
  return dataHora.format(new Date(valor));
}

export function formatarData(valor: string | null | undefined): string {
  if (!valor) return "-";
  const [a, m, d] = valor.slice(0, 10).split("-");
  return `${d}/${m}/${a}`;
}

/** Converte "1.234,56" / "1234.56" / "1234,5" em número com 2 casas. */
export function parseValorBR(valor: string): number {
  const limpo = valor.trim().replace(/\s|R\$/g, "");
  const normalizado = limpo.includes(",") ? limpo.replace(/\./g, "").replace(",", ".") : limpo;
  const n = Number(normalizado);
  return Number.isFinite(n) ? Math.round(n * 100) / 100 : NaN;
}

/** Arredonda para centavos evitando erros de ponto flutuante. */
export function centavos(valor: number): number {
  return Math.round(valor * 100);
}
