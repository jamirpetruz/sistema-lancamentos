import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Lançamentos Financeiros",
  description: "Recebimento de comprovantes e baixa de contas a receber no SAP Business One",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="pt-BR">
      <body className="min-h-screen">{children}</body>
    </html>
  );
}
