"use server";

import bcrypt from "bcryptjs";
import { redirect } from "next/navigation";
import { z } from "zod";
import { encerrarSessao, iniciarSessao } from "@/lib/auth";
import { excedeuLimite, limparFalhas, registrarFalha } from "@/lib/rate-limit";
import { obterUsuarioParaLogin } from "@/lib/repos/usuarios";

export interface LoginState {
  erro?: string;
}

const schema = z.object({
  email: z.string().trim().email("Informe um e-mail válido."),
  senha: z.string().min(1, "Informe a senha."),
});

// Hash usado quando o e-mail não existe, para manter o tempo de resposta constante
let hashFalso: string | undefined;
const HASH_FALSO = () => (hashFalso ??= bcrypt.hashSync("senha-inexistente", 12));

export async function loginAction(_prev: LoginState, formData: FormData): Promise<LoginState> {
  const parsed = schema.safeParse({ email: formData.get("email"), senha: formData.get("senha") });
  if (!parsed.success) return { erro: parsed.error.issues[0].message };

  const email = parsed.data.email.toLowerCase();
  const chave = `login:${email}`;
  if (excedeuLimite(chave)) {
    return { erro: "Muitas tentativas. Aguarde alguns minutos e tente novamente." };
  }

  const usuario = await obterUsuarioParaLogin(email);
  const senhaOk = await bcrypt.compare(parsed.data.senha, usuario?.SenhaHash ?? HASH_FALSO());

  if (!usuario || !senhaOk) {
    registrarFalha(chave);
    return { erro: "E-mail ou senha inválidos." };
  }
  if (!usuario.Ativo) return { erro: "Usuário inativo. Procure o administrador." };

  limparFalhas(chave);
  await iniciarSessao(usuario);
  redirect("/comprovantes");
}

export async function logoutAction(): Promise<void> {
  await encerrarSessao();
  redirect("/login");
}
