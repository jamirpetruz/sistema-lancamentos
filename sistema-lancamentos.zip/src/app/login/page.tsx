import { LoginForm } from "./login-form";

export default function LoginPage() {
  return (
    <main className="flex min-h-screen items-center justify-center px-4">
      <div className="card w-full max-w-sm p-8">
        <div className="mb-6 text-center">
          <h1 className="text-xl font-semibold text-slate-900">Lançamentos Financeiros</h1>
          <p className="mt-1 text-sm text-slate-500">Comprovantes e baixas no SAP Business One</p>
        </div>
        <LoginForm />
      </div>
    </main>
  );
}
