import { Sidebar } from "@/components/sidebar";
import { exigirUsuario } from "@/lib/auth";
import { contarPorStatus } from "@/lib/repos/comprovantes";

export default async function AppLayout({ children }: { children: React.ReactNode }) {
  const usuario = await exigirUsuario();

  let pendentes = 0;
  if (usuario.Role === "admin") {
    const contagem = await contarPorStatus();
    pendentes = contagem.PENDENTE + contagem.ERRO;
  }

  return (
    <div className="min-h-screen lg:pl-64">
      <Sidebar
        usuario={{ nome: usuario.Nome, email: usuario.Email, role: usuario.Role }}
        pendentes={pendentes}
      />
      <main className="px-4 py-6 sm:px-6 lg:px-8 lg:py-8">
        <div className="mx-auto max-w-7xl">{children}</div>
      </main>
    </div>
  );
}
