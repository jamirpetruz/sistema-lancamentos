import Link from "next/link";
import { notFound } from "next/navigation";
import { StatusBadge } from "@/components/status-badge";
import { exigirUsuario } from "@/lib/auth";
import { formatarCnpj, formatarDataHora, formatarMoeda } from "@/lib/format";
import { listarHistorico, listarLancamentos, obterComprovante } from "@/lib/repos/comprovantes";
import { sapEnv } from "@/lib/env";
import { consultarPedidoExterno, sugerirAlocacao, type ConsultaPedidoExterno } from "@/lib/sap/recebimentos";
import { AprovacaoPainel } from "./aprovacao-painel";
import { DestravarBotao, RejeitarForm } from "./decisao-forms";

const ACAO_LABEL: Record<string, string> = {
  ENVIADO: "Comprovante enviado",
  APROVADO: "Aprovado e baixado no SAP",
  REJEITADO: "Rejeitado",
  ERRO_SAP: "Erro ao lançar no SAP",
  DESTRAVADO: "Processamento liberado",
};

function hojeSaoPaulo(): string {
  return new Intl.DateTimeFormat("en-CA", { timeZone: "America/Sao_Paulo" }).format(new Date());
}

export default async function ComprovantePage({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<{ enviado?: string }>;
}) {
  const usuario = await exigirUsuario();
  const { id: idParam } = await params;
  const { enviado } = await searchParams;
  const id = Number(idParam);
  if (!Number.isInteger(id) || id <= 0) notFound();

  const comprovante = await obterComprovante(id);
  if (!comprovante) notFound();
  const isAdmin = usuario.Role === "admin";
  if (!isAdmin && comprovante.UsuarioEnvioId !== usuario.Id) notFound();

  const [historico, lancamentos] = await Promise.all([listarHistorico(id), listarLancamentos(id)]);

  const podeDecidir = isAdmin && (comprovante.Status === "PENDENTE" || comprovante.Status === "ERRO");
  let consulta: ConsultaPedidoExterno | null = null;
  let erroConsulta: string | null = null;
  let validarCnpj = true;
  if (podeDecidir) {
    try {
      validarCnpj = sapEnv().validarCnpj;
      consulta = await consultarPedidoExterno(comprovante.NumeroPedidoExterno, comprovante.Cnpj);
    } catch (err) {
      erroConsulta = err instanceof Error ? err.message : String(err);
    }
  }

  const anexoUrl = `/api/comprovantes/${id}/anexo`;

  return (
    <div className="space-y-6">
      <div>
        <Link href="/comprovantes" className="text-sm text-brand-600 hover:underline">
          ← Voltar
        </Link>
        <div className="mt-2 flex flex-wrap items-center gap-3">
          <h1 className="text-2xl font-semibold text-slate-900">Comprovante #{comprovante.Id}</h1>
          <StatusBadge status={comprovante.Status} />
        </div>
      </div>

      {enviado && comprovante.Status === "PENDENTE" && (
        <p className="rounded-lg bg-emerald-50 px-4 py-3 text-sm text-emerald-800">
          Comprovante enviado com sucesso. Ele será analisado por um administrador.
        </p>
      )}

      <div className="grid gap-6 lg:grid-cols-5">
        <section className="card p-5 lg:col-span-3">
          <h2 className="mb-4 font-semibold text-slate-900">Dados do comprovante</h2>
          <dl className="grid gap-x-6 gap-y-4 sm:grid-cols-2">
            <Campo label="Nº Pedido Externo" valor={comprovante.NumeroPedidoExterno} />
            <Campo label="CNPJ" valor={formatarCnpj(comprovante.Cnpj)} />
            <Campo label="Valor do Comprovante" valor={formatarMoeda(comprovante.ValorComprovante)} destaque />
            <Campo label="Data de Envio" valor={formatarDataHora(comprovante.DataEnvio)} />
            <Campo label="Enviado por" valor={comprovante.UsuarioEnvioNome} />
            {comprovante.AprovadorNome && comprovante.DataDecisao && (
              <Campo
                label={comprovante.Status === "REJEITADO" ? "Rejeitado por" : "Aprovado por"}
                valor={`${comprovante.AprovadorNome} em ${formatarDataHora(comprovante.DataDecisao)}`}
              />
            )}
            <div className="sm:col-span-2">
              <Campo label="Observação" valor={comprovante.Observacao || "-"} />
            </div>
            {comprovante.MotivoRejeicao && (
              <div className="sm:col-span-2">
                <Campo label="Motivo da rejeição" valor={comprovante.MotivoRejeicao} />
              </div>
            )}
          </dl>

          {comprovante.Status === "ERRO" && comprovante.UltimoErroSap && (
            <div className="mt-5 rounded-lg bg-red-50 px-4 py-3 text-sm text-red-800">
              <p className="font-medium">Último erro no SAP</p>
              <p className="mt-1 whitespace-pre-wrap">{comprovante.UltimoErroSap}</p>
            </div>
          )}

          {comprovante.Status === "PROCESSANDO" && (
            <div className="mt-5 rounded-lg bg-sky-50 px-4 py-3 text-sm text-sky-800">
              A baixa está sendo lançada no SAP.
              {isAdmin && (
                <div className="mt-2">
                  <DestravarBotao id={id} />
                </div>
              )}
            </div>
          )}
        </section>

        <section className="card p-5 lg:col-span-2">
          <div className="mb-3 flex items-center justify-between">
            <h2 className="font-semibold text-slate-900">Anexo</h2>
            {comprovante.AnexoNome && (
              <a href={anexoUrl} target="_blank" rel="noopener" className="text-sm text-brand-600 hover:underline">
                Abrir em nova aba
              </a>
            )}
          </div>
          {!comprovante.AnexoNome ? (
            <p className="text-sm text-slate-500">Sem anexo.</p>
          ) : comprovante.AnexoMime === "application/pdf" ? (
            <iframe src={anexoUrl} title="Comprovante" className="h-96 w-full rounded-lg border border-slate-200" />
          ) : (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={anexoUrl} alt="Comprovante" className="w-full rounded-lg border border-slate-200" />
          )}
        </section>
      </div>

      {lancamentos.length > 0 && (
        <section className="card overflow-x-auto p-5">
          <h2 className="mb-3 font-semibold text-slate-900">Lançamentos no SAP</h2>
          <table className="table">
            <thead>
              <tr>
                <th>Contas a Receber (DocNum)</th>
                <th>Cliente</th>
                <th>NF (DocNum)</th>
                <th>Parcela</th>
                <th className="text-right">Valor aplicado</th>
                <th>Data</th>
              </tr>
            </thead>
            <tbody>
              {lancamentos.map((l) => (
                <tr key={l.Id}>
                  <td>
                    {l.PagamentoDocNum ?? "-"} <span className="text-xs text-slate-400">(DocEntry {l.PagamentoDocEntry})</span>
                  </td>
                  <td>{l.CardCode}</td>
                  <td>
                    {l.NotaDocNum ?? "-"} <span className="text-xs text-slate-400">(DocEntry {l.NotaDocEntry})</span>
                  </td>
                  <td>{l.Parcela}</td>
                  <td className="text-right">{formatarMoeda(l.ValorAplicado)}</td>
                  <td>{formatarDataHora(l.CriadoEm)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </section>
      )}

      {podeDecidir && (
        <section className="space-y-4">
          <h2 className="text-lg font-semibold text-slate-900">Aprovação e baixa no SAP</h2>
          {erroConsulta ? (
            <div className="card border-red-200 bg-red-50 p-5 text-sm text-red-800">
              <p className="font-medium">Não foi possível consultar o SAP.</p>
              <p className="mt-1 whitespace-pre-wrap">{erroConsulta}</p>
              <p className="mt-2">Recarregue a página para tentar novamente.</p>
            </div>
          ) : (
            consulta && (
              <AprovacaoPainel
                comprovanteId={id}
                valorComprovante={comprovante.ValorComprovante}
                cnpj={comprovante.Cnpj}
                consulta={consulta}
                sugestao={sugerirAlocacao(consulta.parcelas, comprovante.ValorComprovante)}
                dataPadrao={hojeSaoPaulo()}
                validarCnpj={validarCnpj}
              />
            )
          )}
          <RejeitarForm id={id} />
        </section>
      )}

      <section className="card p-5">
        <h2 className="mb-3 font-semibold text-slate-900">Histórico</h2>
        <ol className="space-y-3">
          {historico.map((h) => (
            <li key={h.Id} className="border-l-2 border-slate-200 pl-3 text-sm">
              <p className="font-medium text-slate-800">{ACAO_LABEL[h.Acao] ?? h.Acao}</p>
              <p className="text-xs text-slate-500">
                {formatarDataHora(h.CriadoEm)} {h.UsuarioNome && `· ${h.UsuarioNome}`}
              </p>
              {h.Detalhe && <p className="mt-1 whitespace-pre-wrap text-slate-600">{h.Detalhe}</p>}
            </li>
          ))}
        </ol>
      </section>
    </div>
  );
}

function Campo({ label, valor, destaque }: { label: string; valor: string; destaque?: boolean }) {
  return (
    <div>
      <dt className="text-xs font-medium uppercase tracking-wide text-slate-500">{label}</dt>
      <dd className={`mt-0.5 whitespace-pre-wrap ${destaque ? "text-lg font-semibold text-slate-900" : "text-slate-800"}`}>
        {valor}
      </dd>
    </div>
  );
}
