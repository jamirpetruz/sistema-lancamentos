"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { exigirAdmin } from "@/lib/auth";
import { formatarMoeda } from "@/lib/format";
import {
  concluirAprovacao,
  destravarComprovante,
  obterComprovante,
  registrarErroSap,
  rejeitarComprovante,
  travarParaProcessamento,
} from "@/lib/repos/comprovantes";
import { lancarBaixa, type PagamentoCriado } from "@/lib/sap/recebimentos";

export interface ResultadoAcao {
  ok?: boolean;
  erro?: string;
  mensagem?: string;
}

const aprovarSchema = z.object({
  dataLancamento: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Data de lançamento inválida."),
  alocacoes: z
    .array(
      z.object({
        chave: z.string().regex(/^\d+-\d+$/),
        valor: z.number().finite().min(0),
      }),
    )
    .max(500),
});

export async function aprovarComprovanteAction(
  id: number,
  dados: { dataLancamento: string; alocacoes: { chave: string; valor: number }[] },
): Promise<ResultadoAcao> {
  const admin = await exigirAdmin();

  const parsed = aprovarSchema.safeParse(dados);
  if (!parsed.success) return { erro: parsed.error.issues[0].message };

  const comprovante = await obterComprovante(id);
  if (!comprovante) return { erro: "Comprovante não encontrado." };
  if (comprovante.Status !== "PENDENTE" && comprovante.Status !== "ERRO") {
    return { erro: "Este comprovante não está pendente de aprovação." };
  }

  if (!(await travarParaProcessamento(id, admin.Id))) {
    return { erro: "O comprovante já está sendo processado por outro usuário ou teve o status alterado." };
  }

  let pagamentos: PagamentoCriado[];
  try {
    pagamentos = await lancarBaixa({
      comprovanteId: id,
      pedidoExterno: comprovante.NumeroPedidoExterno,
      cnpj: comprovante.Cnpj,
      valorComprovante: comprovante.ValorComprovante,
      dataLancamento: parsed.data.dataLancamento,
      alocacoes: parsed.data.alocacoes,
    });
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    await registrarErroSap(id, admin.Id, msg);
    revalidatePath(`/comprovantes/${id}`);
    return { erro: msg };
  }

  const resumo = pagamentos
    .map((p) => `Contas a Receber ${p.docNum ?? p.docEntry} (${p.cardCode}): ${p.itens.map((i) => `NF ${i.docNum}/${i.parcela} ${formatarMoeda(i.valor)}`).join(", ")}`)
    .join(" | ");

  try {
    await concluirAprovacao(
      id,
      admin.Id,
      pagamentos.flatMap((p) =>
        p.itens.map((i) => ({
          pagamentoDocEntry: p.docEntry,
          pagamentoDocNum: p.docNum,
          cardCode: p.cardCode,
          notaDocEntry: i.docEntry,
          notaDocNum: i.docNum,
          parcela: i.parcela,
          valorAplicado: i.valor,
        })),
      ),
      resumo,
    );
  } catch (err) {
    // A baixa existe no SAP, mas não foi gravada aqui: registra para conferência manual
    const msg = `Baixa lançada no SAP, mas houve falha ao gravar no sistema: ${err instanceof Error ? err.message : err}. Lançamentos: ${resumo}`;
    await registrarErroSap(id, admin.Id, msg).catch(() => {});
    revalidatePath(`/comprovantes/${id}`);
    return { erro: msg };
  }

  revalidatePath("/comprovantes");
  revalidatePath(`/comprovantes/${id}`);
  return { ok: true, mensagem: `Comprovante aprovado. ${resumo}` };
}

const motivoSchema = z.string().trim().min(3, "Informe o motivo da rejeição.").max(1000);

export async function rejeitarComprovanteAction(id: number, motivo: string): Promise<ResultadoAcao> {
  const admin = await exigirAdmin();
  const parsed = motivoSchema.safeParse(motivo);
  if (!parsed.success) return { erro: parsed.error.issues[0].message };

  const ok = await rejeitarComprovante(id, admin.Id, parsed.data);
  if (!ok) return { erro: "Este comprovante não pode mais ser rejeitado." };

  revalidatePath("/comprovantes");
  revalidatePath(`/comprovantes/${id}`);
  return { ok: true };
}

export async function destravarComprovanteAction(id: number): Promise<ResultadoAcao> {
  const admin = await exigirAdmin();
  const ok = await destravarComprovante(id, admin.Id);
  if (!ok) return { erro: "O comprovante não está em processamento." };
  revalidatePath(`/comprovantes/${id}`);
  return { ok: true };
}
