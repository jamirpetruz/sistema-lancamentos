"use client";

import { useRouter } from "next/navigation";
import { useMemo, useState, useTransition } from "react";
import { centavos, formatarCnpj, formatarData, formatarMoeda, parseValorBR } from "@/lib/format";
import type { Alocacao, ConsultaPedidoExterno } from "@/lib/sap/recebimentos";
import { aprovarComprovanteAction } from "./actions";

const fmtNum = (v: number) => v.toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 });

export function AprovacaoPainel(props: {
  comprovanteId: number;
  valorComprovante: number;
  cnpj: string;
  consulta: ConsultaPedidoExterno;
  sugestao: Alocacao[];
  dataPadrao: string;
  validarCnpj: boolean;
}) {
  const { consulta, valorComprovante } = props;
  const router = useRouter();
  const [pending, startTransition] = useTransition();
  const [erro, setErro] = useState<string | null>(null);
  const [sucesso, setSucesso] = useState<string | null>(null);
  const [dataLancamento, setDataLancamento] = useState(props.dataPadrao);

  const valoresSugeridos = () =>
    Object.fromEntries(props.sugestao.map((a) => [a.chave, a.valor > 0 ? fmtNum(a.valor) : ""]));
  const [valores, setValores] = useState<Record<string, string>>(valoresSugeridos);

  const resumo = useMemo(() => {
    let aplicado = 0;
    const invalidas = new Set<string>();
    for (const p of consulta.parcelas) {
      const txt = valores[p.chave]?.trim();
      if (!txt) continue;
      const v = parseValorBR(txt);
      if (!Number.isFinite(v) || v < 0 || centavos(v) > centavos(p.valorAberto)) invalidas.add(p.chave);
      else aplicado += centavos(v);
    }
    const diferenca = centavos(valorComprovante) - aplicado;
    return { aplicado: aplicado / 100, diferenca: diferenca / 100, invalidas };
  }, [valores, consulta.parcelas, valorComprovante]);

  const excedeAberto = centavos(valorComprovante) > centavos(consulta.totalAberto);
  const bloqueioCnpj = props.validarCnpj && !consulta.cnpjConfere;
  const tipoBaixa =
    centavos(resumo.aplicado) > 0 && centavos(resumo.aplicado) === centavos(consulta.totalAberto) ? "total" : "parcial";
  const podeAprovar =
    consulta.parcelas.length > 0 &&
    resumo.invalidas.size === 0 &&
    centavos(resumo.diferenca) === 0 &&
    !bloqueioCnpj &&
    !!dataLancamento;

  function aprovar() {
    const alocacoes = consulta.parcelas
      .map((p) => ({ chave: p.chave, valor: parseValorBR(valores[p.chave] ?? "") }))
      .filter((a) => Number.isFinite(a.valor) && a.valor > 0);

    const msg = `Confirmar a baixa de ${formatarMoeda(valorComprovante)} no SAP (${tipoBaixa}) em ${formatarData(dataLancamento)}?\n\nSerá criado o Contas a Receber para ${alocacoes.length} parcela(s).`;
    if (!confirm(msg)) return;

    startTransition(async () => {
      setErro(null);
      const r = await aprovarComprovanteAction(props.comprovanteId, { dataLancamento, alocacoes });
      if (r.erro) {
        setErro(r.erro);
        router.refresh();
      } else {
        setSucesso(r.mensagem ?? "Comprovante aprovado.");
        router.refresh();
      }
    });
  }

  return (
    <div className="space-y-4">
      {/* Conferência do CNPJ */}
      <div
        className={`card p-5 text-sm ${consulta.cnpjConfere ? "border-emerald-200" : bloqueioCnpj ? "border-red-200 bg-red-50" : "border-amber-200 bg-amber-50"}`}
      >
        <p className="font-medium">
          {consulta.clientes.length === 0
            ? "Nenhum documento encontrado no SAP para este Nº de Pedido Externo."
            : consulta.cnpjConfere
              ? `✓ CNPJ ${formatarCnpj(props.cnpj)} confere com o cliente no SAP.`
              : `✗ CNPJ ${formatarCnpj(props.cnpj)} não confere com o cliente dos documentos no SAP.${bloqueioCnpj ? " A aprovação está bloqueada." : ""}`}
        </p>
        {consulta.clientes.length > 0 && (
          <ul className="mt-2 space-y-0.5 text-slate-600">
            {consulta.clientes.map((c) => (
              <li key={c.cardCode}>
                {c.cardCode} – {c.cardName}: {c.cnpjs.length ? c.cnpjs.map(formatarCnpj).join(", ") : "sem CNPJ cadastrado"}
              </li>
            ))}
          </ul>
        )}
      </div>

      {/* Pedidos de venda */}
      <div className="card overflow-x-auto p-5">
        <h3 className="mb-3 font-semibold text-slate-900">Pedidos de Venda ({consulta.pedidos.length})</h3>
        {consulta.pedidos.length === 0 ? (
          <p className="text-sm text-slate-500">Nenhum pedido de venda encontrado.</p>
        ) : (
          <table className="table">
            <thead>
              <tr>
                <th>DocNum</th>
                <th>Cliente</th>
                <th>Data</th>
                <th>Status</th>
                <th className="text-right">Total</th>
              </tr>
            </thead>
            <tbody>
              {consulta.pedidos.map((p) => (
                <tr key={p.docEntry}>
                  <td>{p.docNum}</td>
                  <td>
                    {p.cardCode} – {p.cardName}
                  </td>
                  <td>{formatarData(p.docDate)}</td>
                  <td>{p.status}</td>
                  <td className="text-right">{formatarMoeda(p.docTotal)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* Notas fiscais */}
      <div className="card overflow-x-auto p-5">
        <h3 className="mb-3 font-semibold text-slate-900">Notas Fiscais de Saída ({consulta.notas.length})</h3>
        {consulta.notas.length === 0 ? (
          <p className="text-sm text-slate-500">Nenhuma nota fiscal encontrada.</p>
        ) : (
          <table className="table">
            <thead>
              <tr>
                <th>DocNum</th>
                <th>Cliente</th>
                <th>Emissão</th>
                <th>Vencimento</th>
                <th className="text-right">Total</th>
                <th className="text-right">Pago</th>
                <th className="text-right">Saldo</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {consulta.notas.map((n) => (
                <tr key={n.docEntry}>
                  <td>{n.docNum}</td>
                  <td>
                    {n.cardCode} – {n.cardName}
                  </td>
                  <td>{formatarData(n.docDate)}</td>
                  <td>{formatarData(n.docDueDate)}</td>
                  <td className="text-right">{formatarMoeda(n.docTotal)}</td>
                  <td className="text-right">{formatarMoeda(n.paidToDate)}</td>
                  <td className="text-right font-medium">{formatarMoeda(n.saldo)}</td>
                  <td>{n.aberta ? "Aberta" : "Fechada"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* Rateio */}
      <div className="card overflow-x-auto p-5">
        <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
          <h3 className="font-semibold text-slate-900">Parcelas em aberto e valor a baixar</h3>
          <div className="flex gap-2">
            <button type="button" className="btn-secondary px-3 py-1" onClick={() => setValores(valoresSugeridos())}>
              Distribuir por vencimento
            </button>
            <button type="button" className="btn-secondary px-3 py-1" onClick={() => setValores({})}>
              Limpar
            </button>
          </div>
        </div>

        {consulta.parcelas.length === 0 ? (
          <p className="text-sm text-slate-500">Não há parcelas em aberto para baixa.</p>
        ) : (
          <table className="table">
            <thead>
              <tr>
                <th>NF (DocNum)</th>
                <th>Parcela</th>
                <th>Cliente</th>
                <th>Filial</th>
                <th>Vencimento</th>
                <th className="text-right">Em aberto</th>
                <th className="w-44 text-right">Valor a baixar</th>
              </tr>
            </thead>
            <tbody>
              {consulta.parcelas.map((p) => (
                <tr key={p.chave}>
                  <td>{p.docNum}</td>
                  <td>
                    {p.parcela}/{p.totalParcelas}
                  </td>
                  <td>{p.cardCode}</td>
                  <td>{p.bplId ?? "-"}</td>
                  <td>{formatarData(p.vencimento)}</td>
                  <td className="text-right">{formatarMoeda(p.valorAberto)}</td>
                  <td>
                    <input
                      className={`input text-right ${resumo.invalidas.has(p.chave) ? "border-red-400 ring-2 ring-red-100" : ""}`}
                      inputMode="decimal"
                      placeholder="0,00"
                      value={valores[p.chave] ?? ""}
                      onChange={(e) => setValores((v) => ({ ...v, [p.chave]: e.target.value }))}
                      onBlur={(e) => {
                        const n = parseValorBR(e.target.value);
                        if (e.target.value.trim() && Number.isFinite(n))
                          setValores((v) => ({ ...v, [p.chave]: fmtNum(n) }));
                      }}
                      disabled={pending}
                    />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}

        <div className="mt-5 grid gap-4 border-t border-slate-100 pt-4 text-sm sm:grid-cols-2 lg:grid-cols-5">
          <Resumo label="Valor do comprovante" valor={formatarMoeda(valorComprovante)} />
          <Resumo label="Total em aberto" valor={formatarMoeda(consulta.totalAberto)} />
          <Resumo label="Total aplicado" valor={formatarMoeda(resumo.aplicado)} />
          <Resumo
            label="Diferença"
            valor={formatarMoeda(resumo.diferenca)}
            cor={centavos(resumo.diferenca) === 0 ? "text-emerald-700" : "text-red-700"}
          />
          <div>
            <label className="label" htmlFor="dataLancamento">
              Data do lançamento
            </label>
            <input
              id="dataLancamento"
              type="date"
              className="input"
              value={dataLancamento}
              onChange={(e) => setDataLancamento(e.target.value)}
              disabled={pending}
            />
          </div>
        </div>

        {excedeAberto && consulta.parcelas.length > 0 && (
          <p className="mt-4 rounded-lg bg-amber-50 px-3 py-2 text-sm text-amber-800">
            O valor do comprovante é maior que o saldo em aberto das notas. Rejeite o comprovante ou ajuste no SAP antes de
            aprovar.
          </p>
        )}
        {resumo.invalidas.size > 0 && (
          <p className="mt-4 text-sm text-red-600">Há valores inválidos ou maiores que o saldo em aberto da parcela.</p>
        )}
        {erro && <p className="mt-4 whitespace-pre-wrap rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700">{erro}</p>}
        {sucesso && <p className="mt-4 rounded-lg bg-emerald-50 px-3 py-2 text-sm text-emerald-800">{sucesso}</p>}

        <div className="mt-5 flex items-center justify-end gap-3">
          {podeAprovar && <span className="text-sm text-slate-500">Baixa {tipoBaixa}</span>}
          <button type="button" className="btn-success" disabled={!podeAprovar || pending} onClick={aprovar}>
            {pending ? "Lançando no SAP..." : "Aprovar e baixar no SAP"}
          </button>
        </div>
      </div>
    </div>
  );
}

function Resumo({ label, valor, cor }: { label: string; valor: string; cor?: string }) {
  return (
    <div>
      <p className="text-xs font-medium uppercase tracking-wide text-slate-500">{label}</p>
      <p className={`mt-1 text-base font-semibold ${cor ?? "text-slate-900"}`}>{valor}</p>
    </div>
  );
}
