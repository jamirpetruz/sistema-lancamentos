"use client";

import { useRouter } from "next/navigation";
import { useState, useTransition } from "react";
import { destravarComprovanteAction, rejeitarComprovanteAction } from "./actions";

export function RejeitarForm({ id }: { id: number }) {
  const router = useRouter();
  const [aberto, setAberto] = useState(false);
  const [motivo, setMotivo] = useState("");
  const [erro, setErro] = useState<string | null>(null);
  const [pending, startTransition] = useTransition();

  if (!aberto) {
    return (
      <button type="button" className="btn-secondary text-red-700" onClick={() => setAberto(true)}>
        Rejeitar comprovante
      </button>
    );
  }

  return (
    <div className="card space-y-3 border-red-200 p-5">
      <label className="label" htmlFor="motivo">
        Motivo da rejeição *
      </label>
      <textarea
        id="motivo"
        className="input"
        rows={3}
        maxLength={1000}
        value={motivo}
        onChange={(e) => setMotivo(e.target.value)}
      />
      {erro && <p className="text-sm text-red-600">{erro}</p>}
      <div className="flex gap-2">
        <button
          type="button"
          className="btn-danger"
          disabled={pending}
          onClick={() =>
            startTransition(async () => {
              setErro(null);
              const r = await rejeitarComprovanteAction(id, motivo);
              if (r.erro) setErro(r.erro);
              else router.refresh();
            })
          }
        >
          {pending ? "Rejeitando..." : "Confirmar rejeição"}
        </button>
        <button type="button" className="btn-secondary" onClick={() => setAberto(false)} disabled={pending}>
          Cancelar
        </button>
      </div>
    </div>
  );
}

export function DestravarBotao({ id }: { id: number }) {
  const router = useRouter();
  const [pending, startTransition] = useTransition();
  const [erro, setErro] = useState<string | null>(null);

  return (
    <>
      <button
        type="button"
        className="btn-secondary px-3 py-1"
        disabled={pending}
        onClick={() => {
          if (
            !confirm(
              "Use apenas se o processamento travou (ex.: queda do servidor). O comprovante irá para 'Erro no SAP' e poderá ser reprocessado. Continuar?",
            )
          )
            return;
          startTransition(async () => {
            const r = await destravarComprovanteAction(id);
            if (r.erro) setErro(r.erro);
            else router.refresh();
          });
        }}
      >
        Liberar processamento travado
      </button>
      {erro && <p className="mt-1 text-red-600">{erro}</p>}
    </>
  );
}
