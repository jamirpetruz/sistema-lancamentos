"use server";

import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { z } from "zod";
import { detectarTipoArquivo, nomeArquivoSeguro, TAMANHO_MAXIMO_ANEXO } from "@/lib/arquivo";
import { exigirUsuario } from "@/lib/auth";
import { cnpjValido, parseValorBR, somenteDigitos } from "@/lib/format";
import { criarComprovante } from "@/lib/repos/comprovantes";

export interface NovoComprovanteState {
  erros?: Partial<Record<"pedido" | "cnpj" | "valor" | "observacao" | "anexo" | "geral", string>>;
}

const schema = z.object({
  pedido: z
    .string()
    .trim()
    .min(1, "Informe o Nº do Pedido Externo.")
    .max(100, "Máximo de 100 caracteres."),
  cnpj: z
    .string()
    .transform(somenteDigitos)
    .refine(cnpjValido, "CNPJ inválido."),
  valor: z
    .string()
    .transform(parseValorBR)
    .refine((v) => Number.isFinite(v) && v > 0, "Informe um valor maior que zero.")
    .refine((v) => v < 1e15, "Valor muito alto."),
  observacao: z.string().trim().max(1000, "Máximo de 1000 caracteres.").optional(),
});

export async function enviarComprovanteAction(
  _prev: NovoComprovanteState,
  formData: FormData,
): Promise<NovoComprovanteState> {
  const usuario = await exigirUsuario();

  const parsed = schema.safeParse({
    pedido: formData.get("pedido") ?? "",
    cnpj: formData.get("cnpj") ?? "",
    valor: formData.get("valor") ?? "",
    observacao: formData.get("observacao") ?? undefined,
  });

  const erros: NonNullable<NovoComprovanteState["erros"]> = {};
  if (!parsed.success) {
    for (const issue of parsed.error.issues) {
      const campo = issue.path[0] as keyof typeof erros;
      erros[campo] ??= issue.message;
    }
  }

  const arquivo = formData.get("anexo");
  let anexo: { nome: string; mime: string; conteudo: Buffer } | null = null;
  if (!(arquivo instanceof File) || arquivo.size === 0) {
    erros.anexo = "Anexe a imagem do comprovante.";
  } else if (arquivo.size > TAMANHO_MAXIMO_ANEXO) {
    erros.anexo = "O arquivo deve ter no máximo 5 MB.";
  } else {
    const conteudo = Buffer.from(await arquivo.arrayBuffer());
    const tipo = detectarTipoArquivo(conteudo);
    if (!tipo) erros.anexo = "Formato não suportado. Envie JPG, PNG, WEBP ou PDF.";
    else anexo = { nome: nomeArquivoSeguro(arquivo.name, tipo.ext), mime: tipo.mime, conteudo };
  }

  if (Object.keys(erros).length > 0 || !parsed.success || !anexo) return { erros };

  const id = await criarComprovante({
    numeroPedidoExterno: parsed.data.pedido,
    cnpj: parsed.data.cnpj,
    valor: parsed.data.valor,
    observacao: parsed.data.observacao || null,
    usuarioId: usuario.Id,
    anexo,
  });

  revalidatePath("/comprovantes");
  redirect(`/comprovantes/${id}?enviado=1`);
}
