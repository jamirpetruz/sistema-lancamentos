"use client";

import { startTransition, useActionState, useState } from "react";
import { enviarComprovanteAction, type NovoComprovanteState } from "./actions";

function mascaraCnpj(v: string) {
  const d = v.replace(/\D/g, "").slice(0, 14);
  return d
    .replace(/^(\d{2})(\d)/, "$1.$2")
    .replace(/^(\d{2})\.(\d{3})(\d)/, "$1.$2.$3")
    .replace(/\.(\d{3})(\d)/, ".$1/$2")
    .replace(/(\d{4})(\d)/, "$1-$2");
}

function mascaraValor(v: string) {
  const d = v.replace(/\D/g, "").replace(/^0+(?=\d)/, "");
  if (!d) return "";
  const n = Number(d) / 100;
  return n.toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function Erro({ msg }: { msg?: string }) {
  return msg ? <p className="mt-1 text-sm text-red-600">{msg}</p> : null;
}

export function NovoComprovanteForm() {
  const [state, action, pending] = useActionState<NovoComprovanteState, FormData>(enviarComprovanteAction, {});
  const [cnpj, setCnpj] = useState("");
  const [valor, setValor] = useState("");
  const [preview, setPreview] = useState<string | null>(null);
  const e = state.erros ?? {};

  return (
    <form
      // submit manual para o React não limpar o formulário (e o arquivo) quando houver erro de validação
      onSubmit={(ev) => {
        ev.preventDefault();
        const fd = new FormData(ev.currentTarget);
        startTransition(() => action(fd));
      }}
      className="space-y-5"
    >
      <div className="grid gap-5 sm:grid-cols-2">
        <div className="sm:col-span-2">
          <label className="label" htmlFor="pedido">
            Nº Pedido Externo *
          </label>
          <input id="pedido" name="pedido" className="input" maxLength={100} required />
          <Erro msg={e.pedido} />
        </div>
        <div>
          <label className="label" htmlFor="cnpj">
            CNPJ *
          </label>
          <input
            id="cnpj"
            name="cnpj"
            className="input"
            inputMode="numeric"
            placeholder="00.000.000/0000-00"
            value={cnpj}
            onChange={(ev) => setCnpj(mascaraCnpj(ev.target.value))}
            required
          />
          <Erro msg={e.cnpj} />
        </div>
        <div>
          <label className="label" htmlFor="valor">
            Valor do Comprovante (R$) *
          </label>
          <input
            id="valor"
            name="valor"
            className="input text-right"
            inputMode="numeric"
            placeholder="0,00"
            value={valor}
            onChange={(ev) => setValor(mascaraValor(ev.target.value))}
            required
          />
          <Erro msg={e.valor} />
        </div>
        <div className="sm:col-span-2">
          <label className="label" htmlFor="observacao">
            Observação
          </label>
          <textarea id="observacao" name="observacao" rows={3} maxLength={1000} className="input" />
          <Erro msg={e.observacao} />
        </div>
        <div className="sm:col-span-2">
          <label className="label" htmlFor="anexo">
            Imagem do comprovante * <span className="font-normal text-slate-500">(JPG, PNG, WEBP ou PDF, até 5 MB)</span>
          </label>
          <input
            id="anexo"
            name="anexo"
            type="file"
            accept="image/jpeg,image/png,image/webp,application/pdf"
            required
            className="block w-full text-sm text-slate-600 file:mr-3 file:rounded-lg file:border-0 file:bg-brand-50 file:px-4 file:py-2 file:text-sm file:font-medium file:text-brand-700 hover:file:bg-brand-100"
            onChange={(ev) => {
              const f = ev.target.files?.[0];
              if (preview) URL.revokeObjectURL(preview);
              setPreview(f && f.type.startsWith("image/") ? URL.createObjectURL(f) : null);
            }}
          />
          <Erro msg={e.anexo} />
          {preview && (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={preview} alt="Pré-visualização" className="mt-3 max-h-64 rounded-lg border border-slate-200" />
          )}
        </div>
      </div>

      {e.geral && <p className="rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700">{e.geral}</p>}

      <div className="flex justify-end">
        <button type="submit" className="btn-primary" disabled={pending}>
          {pending ? "Enviando..." : "Enviar comprovante"}
        </button>
      </div>
    </form>
  );
}
