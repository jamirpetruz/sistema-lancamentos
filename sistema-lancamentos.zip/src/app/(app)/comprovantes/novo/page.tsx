import Link from "next/link";
import { exigirUsuario } from "@/lib/auth";
import { NovoComprovanteForm } from "./novo-form";

export default async function NovoComprovantePage() {
  await exigirUsuario();
  return (
    <div className="mx-auto max-w-2xl space-y-5">
      <div>
        <Link href="/comprovantes" className="text-sm text-brand-600 hover:underline">
          ← Voltar
        </Link>
        <h1 className="mt-2 text-2xl font-semibold text-slate-900">Enviar comprovante</h1>
        <p className="text-sm text-slate-500">
          O comprovante ficará pendente até a aprovação de um administrador, que fará a baixa no SAP.
        </p>
      </div>
      <div className="card p-6">
        <NovoComprovanteForm />
      </div>
    </div>
  );
}
