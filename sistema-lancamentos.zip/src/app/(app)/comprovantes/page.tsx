import Link from "next/link";
import { StatusBadge } from "@/components/status-badge";
import { exigirUsuario } from "@/lib/auth";
import { formatarCnpj, formatarDataHora, formatarMoeda } from "@/lib/format";
import { contarPorStatus, listarComprovantes } from "@/lib/repos/comprovantes";
import { STATUS_LABEL, type StatusComprovante } from "@/lib/types";

const POR_PAGINA = 20;

export default async function ComprovantesPage({
  searchParams,
}: {
  searchParams: Promise<{ status?: string; q?: string; pagina?: string }>;
}) {
  const usuario = await exigirUsuario();
  const sp = await searchParams;
  const isAdmin = usuario.Role === "admin";

  const status = sp.status && sp.status in STATUS_LABEL ? (sp.status as StatusComprovante) : undefined;
  const pagina = Math.max(1, Number(sp.pagina) || 1);
  const escopo = isAdmin ? undefined : usuario.Id;

  const [{ itens, total }, contagem] = await Promise.all([
    listarComprovantes({ usuarioId: escopo, status, busca: sp.q, pagina, porPagina: POR_PAGINA }),
    contarPorStatus(escopo),
  ]);
  const totalPaginas = Math.max(1, Math.ceil(total / POR_PAGINA));

  const link = (over: Record<string, string | number | undefined>) => {
    const p = new URLSearchParams();
    const merged = { status, q: sp.q, pagina, ...over };
    for (const [k, v] of Object.entries(merged)) if (v !== undefined && v !== "" && !(k === "pagina" && v === 1)) p.set(k, String(v));
    const qs = p.toString();
    return qs ? `/comprovantes?${qs}` : "/comprovantes";
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-semibold text-slate-900">Comprovantes</h1>
          <p className="text-sm text-slate-500">
            {isAdmin ? "Todos os comprovantes enviados" : "Comprovantes enviados por você"}
          </p>
        </div>
        <Link href="/comprovantes/novo" className="btn-primary">
          + Enviar comprovante
        </Link>
      </div>

      <div className="flex flex-wrap gap-2">
        <Link
          href={link({ status: undefined, pagina: 1 })}
          className={`rounded-full px-3 py-1 text-sm ring-1 ${!status ? "bg-brand-600 text-white ring-brand-600" : "bg-white text-slate-600 ring-slate-200 hover:bg-slate-50"}`}
        >
          Todos
        </Link>
        {(Object.keys(STATUS_LABEL) as StatusComprovante[]).map((s) => (
          <Link
            key={s}
            href={link({ status: s, pagina: 1 })}
            className={`rounded-full px-3 py-1 text-sm ring-1 ${status === s ? "bg-brand-600 text-white ring-brand-600" : "bg-white text-slate-600 ring-slate-200 hover:bg-slate-50"}`}
          >
            {STATUS_LABEL[s]} <span className="opacity-70">({contagem[s]})</span>
          </Link>
        ))}
      </div>

      <form className="flex gap-2" action="/comprovantes" role="search">
        {status && <input type="hidden" name="status" value={status} />}
        <input
          name="q"
          defaultValue={sp.q ?? ""}
          placeholder="Nº do pedido externo ou CNPJ"
          className="input min-w-0 max-w-md flex-1"
        />
        <button className="btn-secondary" type="submit">
          Buscar
        </button>
      </form>

      {/* Mobile: cards */}
      <ul className="space-y-3 md:hidden">
        {itens.length === 0 && (
          <li className="card px-4 py-10 text-center text-sm text-slate-500">Nenhum comprovante encontrado.</li>
        )}
        {itens.map((c) => (
          <li key={c.Id}>
            <Link href={`/comprovantes/${c.Id}`} className="card block p-4 transition active:bg-slate-50">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <p className="text-xs text-slate-500">#{c.Id} · Pedido externo</p>
                  <p className="truncate font-semibold text-slate-900">{c.NumeroPedidoExterno}</p>
                </div>
                <StatusBadge status={c.Status} />
              </div>
              <div className="mt-3 flex items-end justify-between gap-3">
                <div className="min-w-0 text-xs text-slate-500">
                  <p>{formatarCnpj(c.Cnpj)}</p>
                  <p>
                    {formatarDataHora(c.DataEnvio)}
                    {isAdmin && ` · ${c.UsuarioEnvioNome}`}
                  </p>
                </div>
                <p className="shrink-0 text-base font-semibold text-slate-900">{formatarMoeda(c.ValorComprovante)}</p>
              </div>
              {isAdmin && (c.Status === "PENDENTE" || c.Status === "ERRO") && (
                <p className="mt-3 border-t border-slate-100 pt-2 text-sm font-medium text-brand-600">Analisar →</p>
              )}
            </Link>
          </li>
        ))}
      </ul>

      {/* Tablet/desktop: tabela */}
      <div className="card hidden overflow-x-auto md:block">
        <table className="table">
          <thead>
            <tr>
              <th>#</th>
              <th>Nº Pedido Externo</th>
              <th>CNPJ</th>
              <th className="text-right">Valor</th>
              <th>Status</th>
              <th>Data Envio</th>
              {isAdmin && <th>Enviado por</th>}
              <th></th>
            </tr>
          </thead>
          <tbody>
            {itens.length === 0 && (
              <tr>
                <td colSpan={isAdmin ? 8 : 7} className="py-10 text-center text-slate-500">
                  Nenhum comprovante encontrado.
                </td>
              </tr>
            )}
            {itens.map((c) => (
              <tr key={c.Id} className="hover:bg-slate-50">
                <td className="text-slate-500">{c.Id}</td>
                <td className="font-medium">{c.NumeroPedidoExterno}</td>
                <td className="whitespace-nowrap">{formatarCnpj(c.Cnpj)}</td>
                <td className="whitespace-nowrap text-right">{formatarMoeda(c.ValorComprovante)}</td>
                <td>
                  <StatusBadge status={c.Status} />
                </td>
                <td className="whitespace-nowrap">{formatarDataHora(c.DataEnvio)}</td>
                {isAdmin && <td>{c.UsuarioEnvioNome}</td>}
                <td className="text-right">
                  <Link href={`/comprovantes/${c.Id}`} className="text-sm font-medium text-brand-600 hover:underline">
                    {isAdmin && (c.Status === "PENDENTE" || c.Status === "ERRO") ? "Analisar" : "Ver"}
                  </Link>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {totalPaginas > 1 && (
        <div className="flex flex-wrap items-center justify-between gap-3 text-sm text-slate-600">
          <span>
            Página {pagina} de {totalPaginas} · {total} registro(s)
          </span>
          <div className="flex gap-2">
            {pagina > 1 && (
              <Link className="btn-secondary" href={link({ pagina: pagina - 1 })}>
                Anterior
              </Link>
            )}
            {pagina < totalPaginas && (
              <Link className="btn-secondary" href={link({ pagina: pagina + 1 })}>
                Próxima
              </Link>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
