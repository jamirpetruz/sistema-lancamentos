import Link from "next/link";
import { exigirAdmin } from "@/lib/auth";
import { formatarDataHora } from "@/lib/format";
import { listarUsuarios } from "@/lib/repos/usuarios";

export default async function UsuariosPage() {
  await exigirAdmin();
  const usuarios = await listarUsuarios();

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h1 className="text-2xl font-semibold text-slate-900">Usuários</h1>
        <Link href="/usuarios/novo" className="btn-primary">
          + Novo usuário
        </Link>
      </div>
      {/* Mobile: cards */}
      <ul className="space-y-3 md:hidden">
        {usuarios.map((u) => (
          <li key={u.Id}>
            <Link href={`/usuarios/${u.Id}`} className={`card block p-4 active:bg-slate-50 ${u.Ativo ? "" : "opacity-60"}`}>
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <p className="truncate font-semibold text-slate-900">{u.Nome}</p>
                  <p className="truncate text-sm text-slate-500">{u.Email}</p>
                </div>
                <span
                  className={`shrink-0 rounded px-1.5 py-0.5 text-xs uppercase ${u.Role === "admin" ? "bg-brand-50 text-brand-700" : "bg-slate-100 text-slate-600"}`}
                >
                  {u.Role}
                </span>
              </div>
              <p className="mt-2 text-xs text-slate-500">
                {u.Ativo ? "Ativo" : "Inativo"} · criado em {formatarDataHora(u.CriadoEm)}
              </p>
            </Link>
          </li>
        ))}
      </ul>

      <div className="card hidden overflow-x-auto md:block">
        <table className="table">
          <thead>
            <tr>
              <th>Nome</th>
              <th>E-mail</th>
              <th>Role</th>
              <th>Ativo</th>
              <th>Criado em</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {usuarios.map((u) => (
              <tr key={u.Id} className={u.Ativo ? "" : "text-slate-400"}>
                <td className="font-medium">{u.Nome}</td>
                <td>{u.Email}</td>
                <td>
                  <span
                    className={`rounded px-1.5 py-0.5 text-xs uppercase ${u.Role === "admin" ? "bg-brand-50 text-brand-700" : "bg-slate-100 text-slate-600"}`}
                  >
                    {u.Role}
                  </span>
                </td>
                <td>{u.Ativo ? "Sim" : "Não"}</td>
                <td>{formatarDataHora(u.CriadoEm)}</td>
                <td className="text-right">
                  <Link href={`/usuarios/${u.Id}`} className="text-sm font-medium text-brand-600 hover:underline">
                    Editar
                  </Link>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
