"use client";

import Link from "next/link";
import { startTransition, useActionState } from "react";
import type { Usuario } from "@/lib/types";
import type { UsuarioFormState } from "./actions";

export function UsuarioForm({
  usuario,
  action,
}: {
  usuario?: Usuario;
  action: (prev: UsuarioFormState, formData: FormData) => Promise<UsuarioFormState>;
}) {
  const [state, formAction, pending] = useActionState<UsuarioFormState, FormData>(action, {});
  const e = state.erros ?? {};
  const editando = !!usuario;

  return (
    <form
      onSubmit={(ev) => {
        ev.preventDefault();
        const fd = new FormData(ev.currentTarget);
        startTransition(() => formAction(fd));
      }}
      className="space-y-5"
    >
      <div className="grid gap-5 sm:grid-cols-2">
        <div className="sm:col-span-2">
          <label className="label" htmlFor="nome">
            Nome *
          </label>
          <input id="nome" name="nome" className="input" defaultValue={usuario?.Nome} maxLength={150} required />
          {e.nome && <p className="mt-1 text-sm text-red-600">{e.nome}</p>}
        </div>
        <div className="sm:col-span-2">
          <label className="label" htmlFor="email">
            E-mail *
          </label>
          <input
            id="email"
            name="email"
            type="email"
            className="input"
            defaultValue={usuario?.Email}
            maxLength={255}
            required
          />
          {e.email && <p className="mt-1 text-sm text-red-600">{e.email}</p>}
        </div>
        <div>
          <label className="label" htmlFor="senha">
            {editando ? "Nova senha (deixe em branco para manter)" : "Senha *"}
          </label>
          <input
            id="senha"
            name="senha"
            type="password"
            className="input"
            autoComplete="new-password"
            minLength={8}
            maxLength={72}
            required={!editando}
          />
          {e.senha && <p className="mt-1 text-sm text-red-600">{e.senha}</p>}
        </div>
        <div>
          <label className="label" htmlFor="role">
            Role *
          </label>
          <select id="role" name="role" className="input" defaultValue={usuario?.Role ?? "user"}>
            <option value="user">user – envia e acompanha comprovantes</option>
            <option value="admin">admin – aprova e baixa no SAP</option>
          </select>
          {e.role && <p className="mt-1 text-sm text-red-600">{e.role}</p>}
        </div>
        <label className="flex items-center gap-2 text-sm text-slate-700">
          <input type="checkbox" name="ativo" defaultChecked={usuario?.Ativo ?? true} className="h-4 w-4" />
          Usuário ativo
        </label>
      </div>

      {e.geral && <p className="rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700">{e.geral}</p>}

      <div className="flex justify-end gap-2">
        <Link href="/usuarios" className="btn-secondary">
          Cancelar
        </Link>
        <button type="submit" className="btn-primary" disabled={pending}>
          {pending ? "Salvando..." : "Salvar"}
        </button>
      </div>
    </form>
  );
}
