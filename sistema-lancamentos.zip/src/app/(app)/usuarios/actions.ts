"use server";

import bcrypt from "bcryptjs";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { z } from "zod";
import { exigirAdmin } from "@/lib/auth";
import {
  atualizarUsuario,
  contarAdminsAtivos,
  criarUsuario,
  emailEmUso,
  obterUsuario,
} from "@/lib/repos/usuarios";

export interface UsuarioFormState {
  erros?: Partial<Record<"nome" | "email" | "senha" | "role" | "geral", string>>;
}

const base = z.object({
  nome: z.string().trim().min(2, "Informe o nome.").max(150),
  email: z.string().trim().toLowerCase().email("E-mail inválido.").max(255),
  role: z.enum(["admin", "user"], { message: "Selecione a role." }),
  ativo: z.boolean(),
});

const senhaSchema = z
  .string()
  .min(8, "A senha deve ter no mínimo 8 caracteres.")
  .max(72, "A senha deve ter no máximo 72 caracteres.");

function lerForm(formData: FormData) {
  return {
    nome: String(formData.get("nome") ?? ""),
    email: String(formData.get("email") ?? ""),
    role: String(formData.get("role") ?? ""),
    ativo: formData.get("ativo") === "on",
    senha: String(formData.get("senha") ?? ""),
  };
}

function errosDe(issues: z.ZodIssue[]): UsuarioFormState["erros"] {
  const erros: NonNullable<UsuarioFormState["erros"]> = {};
  for (const i of issues) {
    const campo = (i.path[0] ?? "geral") as keyof typeof erros;
    erros[campo] ??= i.message;
  }
  return erros;
}

export async function criarUsuarioAction(_prev: UsuarioFormState, formData: FormData): Promise<UsuarioFormState> {
  await exigirAdmin();
  const dados = lerForm(formData);
  const parsed = base.extend({ senha: senhaSchema }).safeParse(dados);
  if (!parsed.success) return { erros: errosDe(parsed.error.issues) };

  if (await emailEmUso(parsed.data.email)) return { erros: { email: "E-mail já cadastrado." } };

  await criarUsuario({
    nome: parsed.data.nome,
    email: parsed.data.email,
    role: parsed.data.role,
    ativo: parsed.data.ativo,
    senhaHash: await bcrypt.hash(parsed.data.senha, 12),
  });

  revalidatePath("/usuarios");
  redirect("/usuarios");
}

export async function editarUsuarioAction(
  id: number,
  _prev: UsuarioFormState,
  formData: FormData,
): Promise<UsuarioFormState> {
  const admin = await exigirAdmin();
  const atual = await obterUsuario(id);
  if (!atual) return { erros: { geral: "Usuário não encontrado." } };

  const dados = lerForm(formData);
  const parsed = base.extend({ senha: z.union([z.literal(""), senhaSchema]) }).safeParse(dados);
  if (!parsed.success) return { erros: errosDe(parsed.error.issues) };

  if (await emailEmUso(parsed.data.email, id)) return { erros: { email: "E-mail já cadastrado." } };

  // Impede que o sistema fique sem administrador ativo
  const deixaDeSerAdminAtivo = atual.Role === "admin" && atual.Ativo && (parsed.data.role !== "admin" || !parsed.data.ativo);
  if (deixaDeSerAdminAtivo && (await contarAdminsAtivos(id)) === 0) {
    return { erros: { geral: "É necessário manter ao menos um administrador ativo." } };
  }
  if (id === admin.Id && !parsed.data.ativo) {
    return { erros: { geral: "Você não pode desativar o seu próprio usuário." } };
  }

  await atualizarUsuario(id, {
    nome: parsed.data.nome,
    email: parsed.data.email,
    role: parsed.data.role,
    ativo: parsed.data.ativo,
    senhaHash: parsed.data.senha ? await bcrypt.hash(parsed.data.senha, 12) : undefined,
  });

  revalidatePath("/usuarios");
  redirect("/usuarios");
}
