import { notFound } from "next/navigation";
import { exigirAdmin } from "@/lib/auth";
import { obterUsuario } from "@/lib/repos/usuarios";
import { editarUsuarioAction } from "../actions";
import { UsuarioForm } from "../usuario-form";

export default async function EditarUsuarioPage({ params }: { params: Promise<{ id: string }> }) {
  await exigirAdmin();
  const id = Number((await params).id);
  if (!Number.isInteger(id) || id <= 0) notFound();
  const usuario = await obterUsuario(id);
  if (!usuario) notFound();

  return (
    <div className="mx-auto max-w-2xl space-y-5">
      <h1 className="text-2xl font-semibold text-slate-900">Editar usuário</h1>
      <div className="card p-6">
        <UsuarioForm usuario={usuario} action={editarUsuarioAction.bind(null, id)} />
      </div>
    </div>
  );
}
