import { exigirAdmin } from "@/lib/auth";
import { criarUsuarioAction } from "../actions";
import { UsuarioForm } from "../usuario-form";

export default async function NovoUsuarioPage() {
  await exigirAdmin();
  return (
    <div className="mx-auto max-w-2xl space-y-5">
      <h1 className="text-2xl font-semibold text-slate-900">Novo usuário</h1>
      <div className="card p-6">
        <UsuarioForm action={criarUsuarioAction} />
      </div>
    </div>
  );
}
