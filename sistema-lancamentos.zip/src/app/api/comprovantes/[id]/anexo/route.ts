import { NextResponse } from "next/server";
import { usuarioAtual } from "@/lib/auth";
import { obterAnexo } from "@/lib/repos/comprovantes";

export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const usuario = await usuarioAtual();
  if (!usuario) return NextResponse.json({ erro: "Não autenticado" }, { status: 401 });

  const id = Number((await params).id);
  if (!Number.isInteger(id) || id <= 0) return NextResponse.json({ erro: "Inválido" }, { status: 400 });

  const anexo = await obterAnexo(id);
  // Usuário comum só acessa anexos dos próprios comprovantes
  if (!anexo || (usuario.Role !== "admin" && anexo.UsuarioEnvioId !== usuario.Id)) {
    return NextResponse.json({ erro: "Não encontrado" }, { status: 404 });
  }

  const headers: Record<string, string> = {
    "Content-Type": anexo.MimeType,
    "Content-Disposition": `inline; filename="${anexo.NomeArquivo}"`,
    "Content-Length": String(anexo.Conteudo.length),
    "Cache-Control": "private, max-age=300",
    "X-Content-Type-Options": "nosniff",
  };
  // O visualizador de PDF do navegador não funciona em contexto "sandbox"; imagens sim
  if (anexo.MimeType.startsWith("image/")) {
    headers["Content-Security-Policy"] = "default-src 'none'; img-src 'self'; style-src 'unsafe-inline'; sandbox";
  }

  return new NextResponse(new Uint8Array(anexo.Conteudo), { headers });
}
