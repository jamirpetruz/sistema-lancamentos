// Cria (ou reativa e redefine a senha de) um usuário admin.
// Uso: npm run db:create-admin -- "Nome" email@empresa.com "SenhaForte123"
import sql from "mssql";
import bcrypt from "bcryptjs";

const [nome, email, senha] = process.argv.slice(2);
if (!nome || !email || !senha) {
  console.error('Uso: npm run db:create-admin -- "Nome" email@empresa.com "Senha"');
  process.exit(1);
}
if (senha.length < 8) {
  console.error("A senha precisa ter pelo menos 8 caracteres.");
  process.exit(1);
}

const config = {
  server: process.env.DB_SERVER,
  port: Number(process.env.DB_PORT || 1433),
  database: process.env.DB_DATABASE,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  options: {
    encrypt: process.env.DB_ENCRYPT === "true",
    trustServerCertificate: process.env.DB_TRUST_SERVER_CERTIFICATE !== "false",
  },
};

async function main() {
  const pool = await new sql.ConnectionPool(config).connect();
  const hash = await bcrypt.hash(senha, 12);
  const emailNorm = email.trim().toLowerCase();

  const result = await pool
    .request()
    .input("nome", sql.NVarChar(150), nome.trim())
    .input("email", sql.NVarChar(255), emailNorm)
    .input("hash", sql.NVarChar(100), hash).query(`
      MERGE dbo.Usuarios AS t
      USING (SELECT @email AS Email) AS s ON t.Email = s.Email
      WHEN MATCHED THEN
        UPDATE SET Nome = @nome, SenhaHash = @hash, Role = 'admin', Ativo = 1, AtualizadoEm = SYSDATETIME()
      WHEN NOT MATCHED THEN
        INSERT (Nome, Email, SenhaHash, Role, Ativo) VALUES (@nome, @email, @hash, 'admin', 1)
      OUTPUT $action AS Acao, inserted.Id;
    `);

  const row = result.recordset[0];
  console.log(`Admin ${row.Acao === "INSERT" ? "criado" : "atualizado"} (Id ${row.Id}): ${emailNorm}`);
  await pool.close();
}

main().catch((err) => {
  if (err?.code === "ELOGIN") {
    console.error(
      `Falha de login no SQL Server (${config.server}:${config.port}, banco ${config.database}).\n` +
        "Causas comuns:\n" +
        "  1. O banco ainda não foi criado: rode antes  npm run db:init\n" +
        "  2. Usuário/senha incorretos em .env.local (DB_USER / DB_PASSWORD)\n" +
        "  3. DB_SERVER/DB_PORT apontam para outra instância do SQL Server",
    );
  } else {
    console.error(err);
  }
  process.exit(1);
});
