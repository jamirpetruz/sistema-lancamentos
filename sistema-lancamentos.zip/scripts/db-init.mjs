// Cria o banco (se não existir) e aplica sql/schema.sql.
// Uso: npm run db:init   (lê as variáveis de .env.local)
import fs from "node:fs";
import path from "node:path";
import sql from "mssql";

const baseConfig = {
  server: process.env.DB_SERVER,
  port: Number(process.env.DB_PORT || 1433),
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  options: {
    encrypt: process.env.DB_ENCRYPT === "true",
    trustServerCertificate: process.env.DB_TRUST_SERVER_CERTIFICATE !== "false",
  },
};

const database = process.env.DB_DATABASE;
if (!database || !/^[A-Za-z0-9_]+$/.test(database)) {
  console.error("DB_DATABASE ausente ou inválido (use apenas letras, números e _).");
  process.exit(1);
}

async function main() {
  const master = await new sql.ConnectionPool({ ...baseConfig, database: "master" }).connect();
  await master
    .request()
    .input("db", sql.NVarChar, database)
    .query(`IF DB_ID(@db) IS NULL EXEC('CREATE DATABASE [${database}]')`);
  await master.close();
  console.log(`Banco ${database} pronto.`);

  const pool = await new sql.ConnectionPool({ ...baseConfig, database }).connect();
  const script = fs.readFileSync(path.join(process.cwd(), "sql", "schema.sql"), "utf8");
  const batches = script
    .split(/^\s*GO\s*$/gim)
    .map((b) => b.trim())
    .filter(Boolean);

  for (const batch of batches) {
    await pool.request().batch(batch);
  }
  await pool.close();
  console.log(`Schema aplicado (${batches.length} lotes).`);
}

main().catch((err) => {
  if (err?.code === "ELOGIN") {
    console.error(
      `Falha de login no SQL Server (${baseConfig.server}:${baseConfig.port}). ` +
        "Confira DB_USER / DB_PASSWORD e se DB_SERVER/DB_PORT apontam para a instância certa.",
    );
  } else {
    console.error(err);
  }
  process.exit(1);
});
