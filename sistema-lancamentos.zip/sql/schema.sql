/*
  Schema do Sistema de Lançamentos Financeiros (SQL Server)
  Script idempotente: pode ser executado mais de uma vez.
  Os lotes são separados por "GO" (o script scripts/db-init.mjs respeita esse separador).
*/

IF OBJECT_ID('dbo.Usuarios', 'U') IS NULL
BEGIN
  CREATE TABLE dbo.Usuarios (
    Id            INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Usuarios PRIMARY KEY,
    Nome          NVARCHAR(150)     NOT NULL,
    Email         NVARCHAR(255)     NOT NULL,
    SenhaHash     NVARCHAR(100)     NOT NULL,
    Role          VARCHAR(10)       NOT NULL CONSTRAINT DF_Usuarios_Role DEFAULT ('user'),
    Ativo         BIT               NOT NULL CONSTRAINT DF_Usuarios_Ativo DEFAULT (1),
    CriadoEm      DATETIME2(0)      NOT NULL CONSTRAINT DF_Usuarios_CriadoEm DEFAULT (SYSDATETIME()),
    AtualizadoEm  DATETIME2(0)      NULL,
    CONSTRAINT UQ_Usuarios_Email UNIQUE (Email),
    CONSTRAINT CK_Usuarios_Role CHECK (Role IN ('admin', 'user'))
  );
END
GO

IF OBJECT_ID('dbo.Comprovantes', 'U') IS NULL
BEGIN
  CREATE TABLE dbo.Comprovantes (
    Id                  INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Comprovantes PRIMARY KEY,
    NumeroPedidoExterno NVARCHAR(100)     NOT NULL,
    Cnpj                CHAR(14)          NOT NULL,
    ValorComprovante    DECIMAL(19,2)     NOT NULL,
    Status              VARCHAR(15)       NOT NULL CONSTRAINT DF_Comprovantes_Status DEFAULT ('PENDENTE'),
    DataEnvio           DATETIME2(0)      NOT NULL CONSTRAINT DF_Comprovantes_DataEnvio DEFAULT (SYSDATETIME()),
    Observacao          NVARCHAR(1000)    NULL,
    UsuarioEnvioId      INT               NOT NULL,
    AprovadorId         INT               NULL,
    DataDecisao         DATETIME2(0)      NULL,
    MotivoRejeicao      NVARCHAR(1000)    NULL,
    UltimoErroSap       NVARCHAR(2000)    NULL,
    CONSTRAINT FK_Comprovantes_UsuarioEnvio FOREIGN KEY (UsuarioEnvioId) REFERENCES dbo.Usuarios (Id),
    CONSTRAINT FK_Comprovantes_Aprovador    FOREIGN KEY (AprovadorId)    REFERENCES dbo.Usuarios (Id),
    CONSTRAINT CK_Comprovantes_Valor  CHECK (ValorComprovante > 0),
    CONSTRAINT CK_Comprovantes_Status CHECK (Status IN ('PENDENTE', 'PROCESSANDO', 'APROVADO', 'REJEITADO', 'ERRO'))
  );

  CREATE INDEX IX_Comprovantes_Status        ON dbo.Comprovantes (Status, DataEnvio DESC);
  CREATE INDEX IX_Comprovantes_UsuarioEnvio  ON dbo.Comprovantes (UsuarioEnvioId, DataEnvio DESC);
  CREATE INDEX IX_Comprovantes_PedidoExterno ON dbo.Comprovantes (NumeroPedidoExterno);
END
GO

/* Imagem do comprovante, em tabela separada para não pesar nas listagens */
IF OBJECT_ID('dbo.ComprovanteAnexos', 'U') IS NULL
BEGIN
  CREATE TABLE dbo.ComprovanteAnexos (
    ComprovanteId INT             NOT NULL CONSTRAINT PK_ComprovanteAnexos PRIMARY KEY,
    NomeArquivo   NVARCHAR(255)   NOT NULL,
    MimeType      VARCHAR(100)    NOT NULL,
    Tamanho       INT             NOT NULL,
    Conteudo      VARBINARY(MAX)  NOT NULL,
    CONSTRAINT FK_ComprovanteAnexos_Comprovante FOREIGN KEY (ComprovanteId)
      REFERENCES dbo.Comprovantes (Id) ON DELETE CASCADE
  );
END
GO

/* Lançamentos gerados no SAP (um registro por nota/parcela baixada) */
IF OBJECT_ID('dbo.ComprovanteLancamentos', 'U') IS NULL
BEGIN
  CREATE TABLE dbo.ComprovanteLancamentos (
    Id                 INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_ComprovanteLancamentos PRIMARY KEY,
    ComprovanteId      INT               NOT NULL,
    PagamentoDocEntry  INT               NOT NULL,
    PagamentoDocNum    INT               NULL,
    CardCode           NVARCHAR(50)      NOT NULL,
    NotaDocEntry       INT               NOT NULL,
    NotaDocNum         INT               NULL,
    Parcela            INT               NOT NULL,
    ValorAplicado      DECIMAL(19,2)     NOT NULL,
    CriadoEm           DATETIME2(0)      NOT NULL CONSTRAINT DF_ComprovanteLancamentos_CriadoEm DEFAULT (SYSDATETIME()),
    CONSTRAINT FK_ComprovanteLancamentos_Comprovante FOREIGN KEY (ComprovanteId)
      REFERENCES dbo.Comprovantes (Id) ON DELETE CASCADE
  );

  CREATE INDEX IX_ComprovanteLancamentos_Comprovante ON dbo.ComprovanteLancamentos (ComprovanteId);
END
GO

/* Trilha de auditoria */
IF OBJECT_ID('dbo.ComprovanteHistorico', 'U') IS NULL
BEGIN
  CREATE TABLE dbo.ComprovanteHistorico (
    Id            INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_ComprovanteHistorico PRIMARY KEY,
    ComprovanteId INT               NOT NULL,
    UsuarioId     INT               NULL,
    Acao          VARCHAR(30)       NOT NULL,
    Detalhe       NVARCHAR(2000)    NULL,
    CriadoEm      DATETIME2(0)      NOT NULL CONSTRAINT DF_ComprovanteHistorico_CriadoEm DEFAULT (SYSDATETIME()),
    CONSTRAINT FK_ComprovanteHistorico_Comprovante FOREIGN KEY (ComprovanteId)
      REFERENCES dbo.Comprovantes (Id) ON DELETE CASCADE,
    CONSTRAINT FK_ComprovanteHistorico_Usuario FOREIGN KEY (UsuarioId)
      REFERENCES dbo.Usuarios (Id)
  );

  CREATE INDEX IX_ComprovanteHistorico_Comprovante ON dbo.ComprovanteHistorico (ComprovanteId, CriadoEm);
END
GO
